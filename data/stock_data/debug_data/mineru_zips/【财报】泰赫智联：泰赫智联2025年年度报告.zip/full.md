# 宁波泰赫智联股份有限公司

2025 年年度报告

(股票简称：泰赫智联股票代码：603218.SH)(上海证券交易所主板)

披露日期：2026年3月25日

公司统一社会信用代码：91330201MA2H6XW9KF

## 重要提示

一、公司董事会、监事会及董事、监事、高级管理人员保证年度报告内容的真实、准确、完整，不存在虚假记载、误导性陈述或重大遗漏，并承担个别和连带的法律责任。

二、公司2025年度利润分配预案为：以实施权益分派股权登记日登记的总股本为基数，每10股派发现金红利1.60元（含税)，合计派发现金红利1.15亿元（含税），占2025年度归属于上市公司股东净利润的33.63%。该预案尚需提交公司2025年年度股东大会审议。

三、公司全体董事出席了审议本次年度报告的董事会会议，会议以9票同意、0票反对、0票弃权审议通过了本报告。

四、公司2025年度财务报告已经中允会计师事务所(特殊普通合伙）审计，并出具了标准无保留意见审计报告(中允审字[2026]第0526号）。

五、本报告所载未来计划、经营目标等前瞻性陈述不构成公司对投资者的实质性承诺，投资者应当对此保持足够的风险认识。

六、报告期内，不存在控股股东及其关联方非经营性占用公司资金的情况。

七、报告期内，公司不存在违反规定程序对外提供担保的情况。

八、公司负责人霍纪臣、主管会计工作负责人贾亦弛及会计机构负责人（财务部部长）保证本报告中财务报告的真实、准确、完整。

九、敬请投资者认真阅读本报告第四节'管理层讨论与分析'中'风险因素'部分的内容，充分关注公司经营中可能面临的相关风险。

重要提示  
第一节释义  
第二节 致股东的信  
第三节公司简介和主要财务指标  
第四节 管理层讨论与分析  
第五节 董事会报告  
第六节公司治理  
第七节环境、社会责任和其他公司治理  
第八节 重要事项  
第九节股份变动及股东情况  
第十节财务报告  
备查文件目录

## 目录

## 第一节释义

## 释义表

<table><tr><td rowspan=1 colspan=1>术语/简称</td><td rowspan=1 colspan=1>释义</td></tr><tr><td rowspan=1 colspan=1>公司、泰赫智联</td><td rowspan=1 colspan=1>指宁波泰赫智联股份有限公司</td></tr><tr><td rowspan=1 colspan=1>域控制器</td><td rowspan=1 colspan=1>指集成多ECU功能、按域集中控制的汽车电子计算单元</td></tr><tr><td rowspan=1 colspan=1>L2+级辅助驾驶</td><td rowspan=1 colspan=1>指具备组合驾驶辅助功能、需驾驶员监管的辅助驾驶等级</td></tr><tr><td rowspan=1 colspan=1>行泊一体</td><td rowspan=1 colspan=1>指行车辅助与泊车辅助功能集成于单一域控制器的方案</td></tr><tr><td rowspan=1 colspan=1>高速连接器</td><td rowspan=1 colspan=1>指支持车载高速数据传输的连接器产品</td></tr><tr><td rowspan=1 colspan=1>Fakra/Mini-Fakra</td><td rowspan=1 colspan=1>指车载射频连接器接口标准</td></tr><tr><td rowspan=1 colspan=1>ASPICE</td><td rowspan=1 colspan=1>指汽车软件开发过程能力成熟度评估标准</td></tr><tr><td rowspan=1 colspan=1>国产化替代</td><td rowspan=1 colspan=1>指整车厂以国产零部件替代进口方案的采购行为</td></tr></table>

## 第二节 致股东的信

2025年，中国智能汽车产业链完成了从'单点功能'到'集中计算'的切换。泰赫智联实现营业收入38.90亿元，同比增长23.5%；归母净利润3.42亿元，同比增长36.8%；智能驾驶域控制器出货量突破120万套，行泊一体方案在新势力头部客户渗透率过半。

这一年，公司完成了第五代域控制器平台的量产爬坡，单套算力提升至120TOPS的同时成本较上一代下降22%；国产化方面，域控核心物料国产采购比例从46%提升至61%，帮助客户在供应链安全与成本之间找到新平衡。

汽车电子的下半场是'中央计算+区域控制'。2026年，公司将发布跨域融合计算平台样品，并推进高带宽连接器在车载网络升级中的标准化卡位。感谢客户与股东在汽车产业变革期给予的信任。

董事长：霍纪臣 2026年3月

## 第三节 公司简介和主要财务指标

## 一、公司基本情况

公司基本情况
<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">内容</td></tr><tr><td colspan="1" rowspan="1">公司中文全称</td><td colspan="1" rowspan="1">宁波泰赫智联股份有限公司</td></tr><tr><td colspan="1" rowspan="1">证券简称</td><td colspan="1" rowspan="1">泰赫智联</td></tr><tr><td colspan="1" rowspan="1">证券代码</td><td colspan="1" rowspan="1">603218.SH</td></tr><tr><td colspan="1" rowspan="1">上市板块</td><td colspan="1" rowspan="1">上海证券交易所主板</td></tr><tr><td colspan="1" rowspan="1">注册地/总部</td><td colspan="1" rowspan="1">浙江省宁波市鄞州区</td></tr><tr><td colspan="1" rowspan="1">上市时间</td><td colspan="1" rowspan="1">2019年5月</td></tr><tr><td colspan="1" rowspan="1">所处行业</td><td colspan="1" rowspan="1">汽车电子零部件</td></tr><tr><td colspan="1" rowspan="1">董事长</td><td colspan="1" rowspan="1">霍纪臣</td></tr><tr><td colspan="1" rowspan="1">总经理</td><td colspan="1" rowspan="1">程予安</td></tr><tr><td colspan="1" rowspan="1">董事会秘书</td><td colspan="1" rowspan="1">贾亦弛</td></tr><tr><td colspan="1" rowspan="1">审计机构</td><td colspan="1" rowspan="1">中允会计师事务所(特殊普通合伙)</td></tr><tr><td colspan="1" rowspan="1">员工总数（人）</td><td colspan="1" rowspan="1">9,800</td></tr></table>

## 二、公司历史沿革

公司成立于2011年，总部位于浙江宁波，2019年5月在上海证券交易所主板上市，是智能驾驶域控制器与车载高速连接器的核心供应商，客户覆盖国内主要自主品牌、新势力与合资车企。

公司建有宁波、芜湖两大制造基地，域控制器年产能160万套；通过ASPICECL2级认证与IATR16949体系认证，设立智能汽车电子研究院，聚焦域控平台、车载网络与传感融合三大方向。

## 三、主要会计数据和财务指标

近三年主要会计数据和财务指标
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>本年比上年增减</td><td rowspan=1 colspan=1>2023年</td></tr><tr><td rowspan=1 colspan=1>营业收入(亿元)</td><td rowspan=1 colspan=1>38.90</td><td rowspan=1 colspan=1>31.50</td><td rowspan=1 colspan=1>+23.5%</td><td rowspan=1 colspan=1>26.80</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润（亿元）</td><td rowspan=1 colspan=1>3.42</td><td rowspan=1 colspan=1>2.50</td><td rowspan=1 colspan=1>+36.8%</td><td rowspan=1 colspan=1>2.16</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的扣除非经常性损益的净利润 (亿元)</td><td rowspan=1 colspan=1>3.05</td><td rowspan=1 colspan=1>2.22</td><td rowspan=1 colspan=1>+37.4%</td><td rowspan=1 colspan=1>1.92</td></tr><tr><td rowspan=1 colspan=1>经营活动产生的现金流量净额（亿元）</td><td rowspan=1 colspan=1>5.80</td><td rowspan=1 colspan=1>4.60</td><td rowspan=1 colspan=1>+26.1%</td><td rowspan=1 colspan=1>3.90</td></tr><tr><td rowspan=1 colspan=1>基本每股收益（元/股）</td><td rowspan=1 colspan=1>0.47</td><td rowspan=1 colspan=1>0.35</td><td rowspan=1 colspan=1>+36.8%</td><td rowspan=1 colspan=1>0.30</td></tr><tr><td rowspan=1 colspan=1>加权平均净资产收益率（%）</td><td rowspan=1 colspan=1>6.10</td><td rowspan=1 colspan=1>4.80</td><td rowspan=1 colspan=1>增加1.30个百分点</td><td rowspan=1 colspan=1>4.40</td></tr><tr><td rowspan=1 colspan=1>总资产 (亿元)</td><td rowspan=1 colspan=1>102.30</td><td rowspan=1 colspan=1>92.60</td><td rowspan=1 colspan=1>+10.5%</td><td rowspan=1 colspan=1>一</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净资产(亿元)</td><td rowspan=1 colspan=1>58.60</td><td rowspan=1 colspan=1>54.20</td><td rowspan=1 colspan=1>+8.1%</td><td rowspan=1 colspan=1></td></tr></table>

注：除特别注明外，金额单位均为人民币亿元；净资产收益率口径为加权平均。

## 四、非经常性损益项目及金额

2025年非经常性损益项目明细
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>金额（亿元)</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>计入当期损益的政府补助</td><td rowspan=1 colspan=1>0.24</td><td rowspan=1 colspan=1>智能制造与技改专项</td></tr><tr><td rowspan=1 colspan=1>理财收益</td><td rowspan=1 colspan=1>0.08</td><td rowspan=1 colspan=1>闲置资金现金管理</td></tr><tr><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1>0.05</td><td rowspan=1 colspan=1>保险理赔及处置收益</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>0.37</td><td rowspan=1 colspan=1>占归母净利润比例10.8%</td></tr></table>

非经常性损益项目数据来源：公司财务报表附注，并经审计确认。

## 五、分季度主要财务数据

2025年分季度主要财务数据
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>第一季度</td><td rowspan=1 colspan=1>第二季度</td><td rowspan=1 colspan=1>第三季度</td><td rowspan=1 colspan=1>第四季度</td></tr><tr><td rowspan=1 colspan=1>营业收入（亿元）</td><td rowspan=1 colspan=1>8.50</td><td rowspan=1 colspan=1>9.40</td><td rowspan=1 colspan=1>10.20</td><td rowspan=1 colspan=1>10.80</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润(亿元)</td><td rowspan=1 colspan=1>0.72</td><td rowspan=1 colspan=1>0.82</td><td rowspan=1 colspan=1>0.91</td><td rowspan=1 colspan=1>0.97</td></tr></table>

第四节 管理层讨论与分析

## 一、报告期内公司所处行业情况

2025年，中国新能源汽车销量约1,600万辆，L2及以上辅助驾驶新车渗透率超过62%。域控制器随智驾平权从高端车型下探至10-15万元价格带，市场规模同比增长约45%；车载高速连接器随舱内外数据量增长持续扩容。

行业格局方面，智驾芯片供应趋于多元，域控制器竞争从'芯片集成能力'转向'软件工程化+成本控制+交付确定性'的综合能力；国产供应商凭借快速响应与本地化研发配套，在自主品牌与新势力中的份额持续提升。

## 二、报告期内公司从事的主要业务

公司主营业务为智能驾驶域控制器、车载高速连接器及线束、车载电源与传感器的研发、制造与销售。域控制器产品覆盖行泊一体、舱驾一体方向，高速连接器应用于车载网络、智驾摄像链路与显示系统。

报告期内，公司域控制器获得3个新平台定点、连接器新增2条标准化产线，前视摄像链路组件在两家主机厂实现平台化装机。

## 三、营业收入构成及变动分析

2025年分产品/业务收入构成
<table><tr><td rowspan=1 colspan=1>产品/业务</td><td rowspan=1 colspan=1>收入（亿元）</td><td rowspan=1 colspan=1>收入占比</td><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>收入比上年增减</td></tr><tr><td rowspan=1 colspan=1>智能驾驶域控制器</td><td rowspan=1 colspan=1>21.78</td><td rowspan=1 colspan=1>56.0%</td><td rowspan=1 colspan=1>29.6%</td><td rowspan=1 colspan=1>+31.4%</td></tr><tr><td rowspan=1 colspan=1>高速连接器及线束</td><td rowspan=1 colspan=1>12.45</td><td rowspan=1 colspan=1>32.0%</td><td rowspan=1 colspan=1>26.4%</td><td rowspan=1 colspan=1>+15.8%</td></tr><tr><td rowspan=1 colspan=1>车载电源及传感器</td><td rowspan=1 colspan=1>4.67</td><td rowspan=1 colspan=1>12.0%</td><td rowspan=1 colspan=1>22.1%</td><td rowspan=1 colspan=1>+9.6%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>38.90</td><td rowspan=1 colspan=1>100.0%</td><td rowspan=1 colspan=1>27.9%</td><td rowspan=1 colspan=1>+23.5%</td></tr></table>

智能驾驶域控制器收入21.78亿元，同比增长31.4%，是公司最大的增长来源；高速连接器及线束收入12.45亿元，同比增长15.8%，随整车数据架构升级稳步放量；车载电源及传感器收入4.67亿元，同比增长9.6%，保持稳健。

2025年分地区收入构成
<table><tr><td rowspan=1 colspan=1>地区</td><td rowspan=1 colspan=1>收入(亿元）</td><td rowspan=1 colspan=1>收入占比</td></tr><tr><td rowspan=1 colspan=1>境内</td><td rowspan=1 colspan=1>37.68</td><td rowspan=1 colspan=1>96.9%</td></tr><tr><td rowspan=1 colspan=1>境外</td><td rowspan=1 colspan=1>1.22</td><td rowspan=1 colspan=1>3.1%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>38.90</td><td rowspan=1 colspan=1>100.0%</td></tr></table>

注：前五名客户合计销售金额占年度销售总额的61.8%。

## 四、营业成本构成

营业成本构成（占营业成本比例）
<table><tr><td colspan="1" rowspan="1">成本项目</td><td colspan="1" rowspan="1">2025年</td><td colspan="1" rowspan="1">2024年</td><td colspan="1" rowspan="1">变动说明</td></tr><tr><td colspan="1" rowspan="1">芯片及电子元器件</td><td colspan="1" rowspan="1">58.4%</td><td colspan="1" rowspan="1">60.2%</td><td colspan="1" rowspan="1">国产化替代与集中采购降本</td></tr><tr><td colspan="1" rowspan="1">结构件及线材</td><td colspan="1" rowspan="1">16.8%</td><td colspan="1" rowspan="1">15.9%</td><td colspan="1" rowspan="1">轻量化材料导入</td></tr><tr><td colspan="1" rowspan="1">直接人工</td><td colspan="1" rowspan="1">9.2%</td><td colspan="1" rowspan="1">9.0%</td><td colspan="1" rowspan="1">自动化改造</td></tr><tr><td colspan="1" rowspan="1">折旧及其他制造费用</td><td colspan="1" rowspan="1">15.6%</td><td colspan="1" rowspan="1">14.9%</td><td colspan="1" rowspan="1">新产线转固</td></tr></table>

## 五、期间费用与研发投入

## 期间费用变动

<table><tr><td rowspan=1 colspan=1>费用项目</td><td rowspan=1 colspan=1>2025年（亿元）</td><td rowspan=1 colspan=1>2024年（亿元）</td><td rowspan=1 colspan=1>同比</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>1.28</td><td rowspan=1 colspan=1>1.10</td><td rowspan=1 colspan=1>+16.4%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>1.62</td><td rowspan=1 colspan=1>1.42</td><td rowspan=1 colspan=1>+14.1%</td></tr><tr><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>3.80</td><td rowspan=1 colspan=1>3.15</td><td rowspan=1 colspan=1>+20.6%</td></tr><tr><td rowspan=1 colspan=1>财务费用</td><td rowspan=1 colspan=1>0.12</td><td rowspan=1 colspan=1>0.18</td><td rowspan=1 colspan=1>-33.3%</td></tr></table>

研发投入方面，公司2025年研发投入合计3.80亿元，占营业收入比例9.8%，其中费用化研发费用3.80亿元、资本化研发投入0.00亿元；研发人员1,620人，占员工总数比例16.5%。

## 六、现金流量情况

现金流量主要项目
<table><tr><td rowspan=2 colspan=1>项目经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>2025年(亿元）</td><td rowspan=1 colspan=1>2024年(亿元)</td></tr><tr><td rowspan=1 colspan=1>5.80</td><td rowspan=1 colspan=1>4.60</td></tr><tr><td rowspan=1 colspan=1>投资活动产生的现金流量净额</td><td rowspan=1 colspan=1>-5.20</td><td rowspan=1 colspan=1>-4.60</td></tr><tr><td rowspan=1 colspan=1>筹资活动产生的现金流量净额</td><td rowspan=1 colspan=1>0.80</td><td rowspan=1 colspan=1>-0.60</td></tr></table>

报告期内经营活动现金流量净额5.80亿元，同比增长26.1%；投资活动净流出5.20亿元，主要为域控产线与芜湖基地投入；筹资活动净流入0.80亿元，主要为项目贷款。

## 七、资产及负债项目重大变动

## 资产、负债项目重大变动

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末（亿元）</td><td rowspan=1 colspan=1>期初（亿元）</td><td rowspan=1 colspan=1>变动比例</td><td rowspan=1 colspan=1>变动原因</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>9.80</td><td rowspan=1 colspan=1>8.40</td><td rowspan=1 colspan=1>+16.7%</td><td rowspan=1 colspan=1>经营积累</td></tr><tr><td rowspan=1 colspan=1>应收账款及应收票据</td><td rowspan=1 colspan=1>18.60</td><td rowspan=1 colspan=1>15.20</td><td rowspan=1 colspan=1>+22.4%</td><td rowspan=1 colspan=1>出货量增长</td></tr><tr><td rowspan=1 colspan=1>存货</td><td rowspan=1 colspan=1>9.40</td><td rowspan=1 colspan=1>7.80</td><td rowspan=1 colspan=1>+20.5%</td><td rowspan=1 colspan=1>新平台量产备货</td></tr><tr><td rowspan=1 colspan=1>固定资产</td><td rowspan=1 colspan=1>18.20</td><td rowspan=1 colspan=1>16.40</td><td rowspan=1 colspan=1>+11.0%</td><td rowspan=1 colspan=1>芜湖基地二期投产</td></tr><tr><td rowspan=1 colspan=1>在建工程</td><td rowspan=1 colspan=1>2.60</td><td rowspan=1 colspan=1>4.20</td><td rowspan=1 colspan=1>-38.1%</td><td rowspan=1 colspan=1>技改项目陆续转固</td></tr></table>

## 八、公司未来发展的展望

2026年经营目标：营业收入48亿元左右，同比增长23%以上；域控制器出货量180万套，舱驾一体平台完成两家客户定点。公司将推动域控核心BOM国产化比例提升至70%。

公司已启动跨域融合计算平台的A样开发，预计2026年内交付客户联调；同时拓展连接器在机器人与低空载具的标准化应用，培育第二增长曲线。

## 九、风险因素

公司在本报告期及未来经营中可能面临以下主要风险，敬请投资者关注：

客户集中风险：公司前五名客户收入占比61.8%，整车厂年降与订单波动影响较大。

价格压力风险：汽车电子面临持续的年度降价压力，若降本节奏不及年降幅度将侵蚀毛利率。

技术路线风险：智驾技术路线(纯视觉/多传感融合）与芯片平台切换快，若公司平台适配滞后将影响定点获取。

质量与召回风险：汽车电子产品对可靠性要求极高，任何质量事件都可能影响客户关系与品牌。

原材料风险：芯片及铜材价格波动对成本有直接影响。

## 第五节 董事会报告

报告期内，公司共召开董事会会议8次、监事会会议4次、股东大会2次。公司董事会严格执行股东大会决议，勤勉尽责开展各项工作，2025年6月完成了上一年度利润分配方案的实施。

公司2025年度利润分配预案为：以实施权益分派股权登记日登记的总股本为基数，每10股派发现金红利1.60元(含税)，合计派发现金红利1.15亿元（含税)，占2025年度归属于上市公司股东净利润的33.63%。

公司2025年度财务报告审计机构为中允会计师事务所(特殊普通合伙），报告期内公司不存在改聘、解聘会计师事务所的情形。公司已就2026年度财务报告审计服务续聘中允会计师事务所（特殊普通合伙）并提请股东大会审议，审计收费180万元。

## 第六节 公司治理

报告期内，公司按照《公司法》《证券法》《上市公司治理准则》及公司章程的要求规范运作。公司董事会由9名董事组成，其中独立董事3名，占比不低于三分之一；监事会由3名监事组成，其中职工代表监事1名。董事会下设战略委员会、审计委员会、提名委员会、薪酬与考核委员会四个专门委员会，报告期内共召开专门委员会会议6次。

投资者关系方面，报告期内公司通过业绩说明会、投资者调研接待、互动平台答复等方式与投资者保持沟通，共接待机构投资者调研28批次，举办业绩说明会3次，回复互动平台提问120条。

内部控制方面，公司已建立覆盖全部业务流程的内部控制体系，报告期内未发现财务报告内部控制重大缺陷或重要缺陷。

## 第七节环境、社会责任和其他公司治理

## 一、环境保护信息

## 环境信息主要指标

<table><tr><td rowspan=1 colspan=1>指标</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>同比变动</td></tr><tr><td rowspan=1 colspan=1>综合能耗（万吨标准煤）</td><td rowspan=1 colspan=1>3.12</td><td rowspan=1 colspan=1>+6.5%</td></tr><tr><td rowspan=1 colspan=1>温室气体排放范围一+二（万吨CO2e）</td><td rowspan=1 colspan=1>11.20</td><td rowspan=1 colspan=1>+5.8%</td></tr><tr><td rowspan=1 colspan=1>水资源消耗 (万立方米)</td><td rowspan=1 colspan=1>58.4</td><td rowspan=1 colspan=1>+2.5%</td></tr><tr><td rowspan=1 colspan=1>环保投入（万元)</td><td rowspan=1 colspan=1>2,260</td><td rowspan=1 colspan=1>+14.0%</td></tr></table>

公司将绿色制造纳入新基地规划：芜湖二期工厂获评绿色建筑二星级设计标识，实施焊接车间烟雾集中处理与注塑水口料全回收，单位产值能耗同比下降4.4%。

## 二、社会责任

截至报告期末，公司员工总数9,800人，其中研发人员1,620人。报告期内公司持续完善职业发展通道与培训体系，人均培训时长24小时；全年对外捐赠及公益投入260万元，重点投向教育帮扶与乡村振兴领域。

## 三、公司治理专项情况

报告期内，公司控股股东、实际控制人不存在违规占用公司资金的情况，公司及控股子公司未发生违规对外担保。公司已披露ESG相关专项报告，详情见公司可持续发展报告。

## 第八节 重要事项

重大诉讼、仲裁事项：报告期内公司不存在重大诉讼、仲裁事项。

对外担保：报告期内公司不存在对外担保事项。

关联交易：报告期内公司与参股公司发生的日常关联交易合计380万元，主要为联合研发费用分摊，程序合规。

承诺履行情况：公司控股股东、实际控制人及董监高报告期内不存在违反承诺情形。

重大合同：报告期内公司获得域控制器与连接器新定点项目12个，预计生命周期总金额约58亿元，符合披露标准的已披露。

## 第九节 股份变动及股东情况

股份结构(万股)
<table><tr><td rowspan=1 colspan=1>股份类别</td><td rowspan=1 colspan=1>数量(万股)</td><td rowspan=1 colspan=1>占总股本比例</td></tr><tr><td rowspan=1 colspan=1>无限售条件流通股</td><td rowspan=1 colspan=1>71,280.0</td><td rowspan=1 colspan=1>99.00%</td></tr><tr><td rowspan=1 colspan=1>限售股</td><td rowspan=1 colspan=1>720.0</td><td rowspan=1 colspan=1>1.00%</td></tr><tr><td rowspan=1 colspan=1>股份总数</td><td rowspan=1 colspan=1>72,000.0</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

## 前十大股东持股情况

截至2025年12月31日前十大股东
<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>股东名称</td><td rowspan=1 colspan=1>持股比例</td><td rowspan=1 colspan=1>股东性质</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>泰赫控股集团有限公司</td><td rowspan=1 colspan=1>18.60%</td><td rowspan=1 colspan=1>境内非国有法人</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>宁波通商集团有限公司</td><td rowspan=1 colspan=1>6.80%</td><td rowspan=1 colspan=1>国有法人</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>泓擎汽车电子基金（有限合伙）</td><td rowspan=1 colspan=1>5.40%</td><td rowspan=1 colspan=1>境内非国有法人</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>香港中央结算有限公司</td><td rowspan=1 colspan=1>3.60%</td><td rowspan=1 colspan=1>境外法人</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>国投创益产业基金</td><td rowspan=1 colspan=1>3.20%</td><td rowspan=1 colspan=1>国有法人</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>全国社保基金一零三组合</td><td rowspan=1 colspan=1>2.40%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>基本养老保险基金八零四组合</td><td rowspan=1 colspan=1>2.00%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>中证A500交易型开放式指数基金</td><td rowspan=1 colspan=1>1.80%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>太平洋人寿保险- 分红险产品</td><td rowspan=1 colspan=1>1.40%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>泰合致远员工持股计划</td><td rowspan=1 colspan=1>1.20%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>前十大股东合计</td><td rowspan=1 colspan=1>46.40%</td><td rowspan=1 colspan=1></td></tr></table>

公司控股股东为泰赫控股集团有限公司，实际控制人为霍纪臣。控股股东所持股份报告期内不存在质押、冻结情形。

## 第十节 财务报告

## 一、审计意见

公司2025年度财务报表业经中允会计师事务所(特殊普通合伙）审计，并于2026年3月出具了标准无保留意见(中允审字[2026]第0526号）。审计机构认为：公司财务报表在所有重大方面按照企业会计准则的规定编制，公允反映了公司2025年12月31日的合并及公司财务状况以及2025年度的合并及公司经营成果和现金流量。

## 二、合并资产负债表主要项目（摘要)

资产负债表主要项目
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末（亿元）</td><td rowspan=1 colspan=1>期初(亿元)</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>9.80</td><td rowspan=1 colspan=1>8.40</td></tr><tr><td rowspan=1 colspan=1>应收账款及应收票据</td><td rowspan=1 colspan=1>18.60</td><td rowspan=1 colspan=1>15.20</td></tr><tr><td rowspan=1 colspan=1>存货</td><td rowspan=1 colspan=1>9.40</td><td rowspan=1 colspan=1>7.80</td></tr><tr><td rowspan=1 colspan=1>固定资产</td><td rowspan=1 colspan=1>18.20</td><td rowspan=1 colspan=1>16.40</td></tr><tr><td rowspan=1 colspan=1>资产总计</td><td rowspan=1 colspan=1>102.30</td><td rowspan=1 colspan=1>92.60</td></tr><tr><td rowspan=1 colspan=1>短期借款</td><td rowspan=1 colspan=1>9.60</td><td rowspan=1 colspan=1>7.80</td></tr><tr><td rowspan=1 colspan=1>合同负债</td><td rowspan=1 colspan=1>1.80</td><td rowspan=1 colspan=1>1.40</td></tr><tr><td rowspan=1 colspan=1>其他负债</td><td rowspan=1 colspan=1>32.30</td><td rowspan=1 colspan=1>29.20</td></tr><tr><td rowspan=1 colspan=1>负债合计</td><td rowspan=1 colspan=1>43.70</td><td rowspan=1 colspan=1>38.40</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东权益合计</td><td rowspan=1 colspan=1>58.60</td><td rowspan=1 colspan=1>54.20</td></tr></table>

注：上述为合并口径主要项目摘要，完整资产负债表及附注以公司指定信息披露媒体披露的版本为准。

## 三、合并利润表主要项目（摘要)

## 利润表主要项目

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年（亿元）</td><td rowspan=1 colspan=1>2024年（亿元）</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>38.90</td><td rowspan=1 colspan=1>31.50</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>28.05</td><td rowspan=1 colspan=1>22.96</td></tr><tr><td rowspan=1 colspan=1>期间费用合计</td><td rowspan=1 colspan=1>6.82</td><td rowspan=1 colspan=1>5.85</td></tr><tr><td rowspan=1 colspan=1>研发费用（含于期间费用）</td><td rowspan=1 colspan=1>3.80</td><td rowspan=1 colspan=1>3.15</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的净利润</td><td rowspan=1 colspan=1>3.42</td><td rowspan=1 colspan=1>2.50</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的扣除非经常性损益的净利润</td><td rowspan=1 colspan=1>3.05</td><td rowspan=1 colspan=1>2.22</td></tr></table>

## 四、合并现金流量表主要项目(摘要)

现金流量表主要项目

<table><tr><td rowspan=2 colspan=1>项目经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>2025年(亿元）</td><td rowspan=1 colspan=1>2024年（亿元）</td></tr><tr><td rowspan=1 colspan=1>5.80</td><td rowspan=1 colspan=1>4.60</td></tr><tr><td rowspan=1 colspan=1>投资活动产生的现金流量净额</td><td rowspan=1 colspan=1>-5.20</td><td rowspan=1 colspan=1>-4.60</td></tr><tr><td rowspan=1 colspan=1>筹资活动产生的现金流量净额</td><td rowspan=1 colspan=1>0.80</td><td rowspan=1 colspan=1>-0.60</td></tr></table>

公司执行财政部颁布的企业会计准则及相关规定，主要会计政策与上一年度保持一致，报告期内无重大会计估计变更。

## 备查文件目录

载有公司法定代表人、主管会计工作负责人、会计机构负责人签名并盖章的财务报表。

载有会计师事务所盖章、注册会计师签名并盖章的2025年度审计报告原件。

·报告期内公开披露过的所有公司文件的正本及公告原稿。

公司2025年年度股东大会会议资料及决议。

(本报告为模拟数据，仅供研究测试使用，不构成任何投资建议)