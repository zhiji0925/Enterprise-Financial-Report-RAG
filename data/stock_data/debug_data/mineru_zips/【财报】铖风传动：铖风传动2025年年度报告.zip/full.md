# 德阳铖风传动股份有限公司

2025 年年度报告

(股票简称：铖风传动股票代码：300796.SZ)(深圳证券交易所创业板)

披露日期：2026年4月2日

公司统一社会信用代码：91510600MA62H7Q3XL

## 重要提示

一、公司董事会、监事会及董事、监事、高级管理人员保证年度报告内容的真实、准确、完整，不存在虚假记载、误导性陈述或重大遗漏，并承担个别和连带的法律责任。

二、公司2025年度利润分配预案为：以实施权益分派股权登记日登记的总股本为基数，每10股派发现金红利1.20元(含税)，合计派发现金红利1.39亿元（含税)，占2025年度归属于上市公司股东净利润的22.38%。该预案尚需提交公司2025年年度股东大会审议。

三、公司全体董事出席了审议本次年度报告的董事会会议，会议以9票同意、0票反对、0票弃权审议通过了本报告。

四、公司2025年度财务报告已经中衡会计师事务所（特殊普通合伙）审计，并出具了标准无保留意见审计报告(中衡审字[2026]第0649号）。

五、本报告所载未来计划、经营目标等前瞻性陈述不构成公司对投资者的实质性承诺，投资者应当对此保持足够的风险认识。

六、报告期内，不存在控股股东及其关联方非经营性占用公司资金的情况。

七、报告期内，公司不存在违反规定程序对外提供担保的情况。

八、公司负责人严啸崑、主管会计工作负责人邬聆夏及会计机构负责人（财务部部长）保证本报告中财务报告的真实、准确、完整。

九、敬请投资者认真阅读本报告第四节'管理层讨论与分析'中'风险因素'部分的内容，充分关注公司经营中可能面临的相关风险。

重要提示  
第一节释义  
第二节 致股东的信  
第三节公司简介和主要财务指标  
第四节 管理层讨论与分析  
第五节 董事会报告  
第六节公司治理  
第七节环境、社会责任和其他公司治理  
第八节 重要事项  
第九节股份变动及股东情况  
第十节财务报告  
备查文件目录

## 目录

## 第一节释义

## 释义表

<table><tr><td rowspan=1 colspan=1>术语/简称</td><td rowspan=1 colspan=1>释义</td></tr><tr><td rowspan=1 colspan=1>公司、铖风传动</td><td rowspan=1 colspan=1>指德阳铖风传动股份有限公司</td></tr><tr><td rowspan=1 colspan=1>主轴承</td><td rowspan=1 colspan=1>指风机组主轴与齿轮箱间承受径向与轴向载荷的核心轴承</td></tr><tr><td rowspan=1 colspan=1>大兆瓦</td><td rowspan=1 colspan=1>指单机容量10MW及以上的风力发电机组</td></tr><tr><td rowspan=1 colspan=1>offshore/海上风电</td><td rowspan=1 colspan=1>指建于近海海域的风电项目</td></tr><tr><td rowspan=1 colspan=1>SKF同源</td><td rowspan=1 colspan=1>指与欧洲轴承工艺体系相当的热处理与磨削工艺路线</td></tr><tr><td rowspan=1 colspan=1>PEEK保持架</td><td rowspan=1 colspan=1>指采用聚醚醚酮材料制造的高性能轴承保持架</td></tr><tr><td rowspan=1 colspan=1>齿轮箱行星轮</td><td rowspan=1 colspan=1>指齿轮箱内传递扭矩的行星传动结构零件</td></tr><tr><td rowspan=1 colspan=1>回转支承</td><td rowspan=1 colspan=1>指承受综合载荷的大型轴承，用于变桨与偏航机构</td></tr></table>

## 第二节 致股东的信

2025年，海上风电从'抢装'走向'常态化'，中国大兆瓦机组批量下海。铖风传动实现营业收入64.50亿元，同比增长24.5%；归母净利润6.21亿元，同比增长34.0%；风电主轴承国内市占率提升至约24%，出口收入占比达28%。

主轴承是风机'卡脖子'环节的最后一块拼图。这一年，公司16.8MW海上平台主轴承通过客户800小时台架考核并批量交付；齿轮箱行星轮系在两家头部整机厂完成平台化导入；德阳基地大兆瓦产线满产，海外订单排至2027年。

风是自由的，但轴承的公差是以微米计的。铖风人始终相信，把最基础的工艺做到极致，就是最好的战略。2026年，我们将随中国海上风电走向更深更远。感谢股东、客户与全体铖风人的坚守。

董事长：严啸崑2026年3月

## 第三节 公司简介和主要财务指标

## 一、公司基本情况

公司基本情况
<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">内容</td></tr><tr><td colspan="1" rowspan="1">公司中文全称</td><td colspan="1" rowspan="1">德阳铖风传动股份有限公司</td></tr><tr><td colspan="1" rowspan="1">证券简称</td><td colspan="1" rowspan="1">铖风传动</td></tr><tr><td colspan="1" rowspan="1">证券代码</td><td colspan="1" rowspan="1">300796.SZ</td></tr><tr><td colspan="1" rowspan="1">上市板块</td><td colspan="1" rowspan="1">深圳证券交易所创业板</td></tr><tr><td colspan="1" rowspan="1">注册地/总部</td><td colspan="1" rowspan="1">四川省德阳市旌阳区</td></tr><tr><td colspan="1" rowspan="1">上市时间</td><td colspan="1" rowspan="1">2020年8月</td></tr><tr><td colspan="1" rowspan="1">所处行业</td><td colspan="1" rowspan="1">风电核心零部件（轴承与传动系统）</td></tr><tr><td colspan="1" rowspan="1">董事长</td><td colspan="1" rowspan="1">严啸崑</td></tr><tr><td colspan="1" rowspan="1">总经理</td><td colspan="1" rowspan="1">芮正南</td></tr><tr><td colspan="1" rowspan="1">董事会秘书</td><td colspan="1" rowspan="1">邬聆夏</td></tr><tr><td colspan="1" rowspan="1">审计机构</td><td colspan="1" rowspan="1">中衡会计师事务所(特殊普通合伙)</td></tr><tr><td colspan="1" rowspan="1">员工总数（人）</td><td colspan="1" rowspan="1">8,400</td></tr></table>

## 二、公司历史沿革

公司成立于2008年，总部位于四川德阳，2020年8月在深圳证券交易所创业板上市，是国内风电主轴承与齿轮箱传动零件的头部企业，国家级制造业单项冠军示范企业。

公司建有德阳、自贡两大基地，具备锻造、热处理、磨装一体化制造能力；大兆瓦主轴承年产能6,000套，产品覆盖3MW至18MW全平台机型。

## 三、主要会计数据和财务指标

## 近三年主要会计数据和财务指标

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>本年比上年增减</td><td rowspan=1 colspan=1>2023年</td></tr><tr><td rowspan=1 colspan=1>营业收入(亿元)</td><td rowspan=1 colspan=1>64.50</td><td rowspan=1 colspan=1>51.80</td><td rowspan=1 colspan=1>+24.5%</td><td rowspan=1 colspan=1>42.60</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润（亿元）</td><td rowspan=1 colspan=1>6.21</td><td rowspan=1 colspan=1>4.63</td><td rowspan=1 colspan=1>+34.1%</td><td rowspan=1 colspan=1>4.28</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的扣除非经常性损益的净利润 (亿元)</td><td rowspan=1 colspan=1>5.58</td><td rowspan=1 colspan=1>4.16</td><td rowspan=1 colspan=1>+34.1%</td><td rowspan=1 colspan=1>3.85</td></tr><tr><td rowspan=1 colspan=1>经营活动产生的现金流量净额（亿元）</td><td rowspan=1 colspan=1>9.80</td><td rowspan=1 colspan=1>7.90</td><td rowspan=1 colspan=1>+24.1%</td><td rowspan=1 colspan=1>6.20</td></tr><tr><td rowspan=1 colspan=1>基本每股收益（元/股）</td><td rowspan=1 colspan=1>0.54</td><td rowspan=1 colspan=1>0.40</td><td rowspan=1 colspan=1>+34.1%</td><td rowspan=1 colspan=1>0.37</td></tr><tr><td rowspan=1 colspan=1>加权平均净资产收益率（%)</td><td rowspan=1 colspan=1>7.30</td><td rowspan=1 colspan=1>5.90</td><td rowspan=1 colspan=1>增加1.40个百分点</td><td rowspan=1 colspan=1>5.80</td></tr><tr><td rowspan=1 colspan=1>总资产 (亿元)</td><td rowspan=1 colspan=1>158.40</td><td rowspan=1 colspan=1>142.60</td><td rowspan=1 colspan=1>+11.1%</td><td rowspan=1 colspan=1>一</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净资产（亿元）</td><td rowspan=1 colspan=1>88.20</td><td rowspan=1 colspan=1>80.90</td><td rowspan=1 colspan=1>+9.0%</td><td rowspan=1 colspan=1>一</td></tr></table>

注：除特别注明外，金额单位均为人民币亿元；净资产收益率口径为加权平均。

## 四、非经常性损益项目及金额

2025年非经常性损益项目明细
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>金额（亿元）</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>计入当期损益的政府补助</td><td rowspan=1 colspan=1>0.42</td><td rowspan=1 colspan=1>高端装备制造业专项及技改贴息</td></tr><tr><td rowspan=1 colspan=1>理财收益</td><td rowspan=1 colspan=1>0.13</td><td rowspan=1 colspan=1>闲置募集资金现金管理</td></tr><tr><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1>0.08</td><td rowspan=1 colspan=1>废钢回收及处置收益</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>0.63</td><td rowspan=1 colspan=1>占归母净利润比例10.1%</td></tr></table>

非经常性损益项目数据来源：公司财务报表附注，并经审计确认。

## 五、分季度主要财务数据

2025年分季度主要财务数据
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>第一季度</td><td rowspan=1 colspan=1>第二季度</td><td rowspan=1 colspan=1>第三季度</td><td rowspan=1 colspan=1>第四季度</td></tr><tr><td rowspan=1 colspan=1>营业收入（亿元）</td><td rowspan=1 colspan=1>13.20</td><td rowspan=1 colspan=1>15.30</td><td rowspan=1 colspan=1>16.80</td><td rowspan=1 colspan=1>19.20</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润(亿元)</td><td rowspan=1 colspan=1>1.16</td><td rowspan=1 colspan=1>1.42</td><td rowspan=1 colspan=1>1.66</td><td rowspan=1 colspan=1>1.97</td></tr></table>

## 第四节 管理层讨论与分析

## 一、报告期内公司所处行业情况

2025年，国内风电新增装机容量超过110GW，其中海上风电新增约12GW，同比增长约30%；大兆瓦与长叶片趋势下，主轴承单机价值量持续提升。全球风电轴承市场规模约260亿元，国产化率由三年前的不足20%提升至约45%。

出口市场方面，欧洲与亚太海上风电建设共振，海外整机厂出于交付确定性与成本考虑加速导入中国供应链；具备大兆瓦批量交付记录与质量数据积累的轴承厂商，正在全球招标中从'备选'转为'主供'。

## 二、报告期内公司从事的主要业务

公司主营业务为风电主轴承、齿轮箱零件及回转支承等传动部件的研发、制造与销售，同时为整机厂提供传动系统联合开发服务。产品覆盖陆上与海上风电全平台。

报告期内，公司16.8MW海上主轴承批量交付，配套国内四家头部整机厂；齿轮箱行星轮系随两家整机厂平台放量；在矿山与盾构传动领域的回转支承业务保持稳定。

## 三、营业收入构成及变动分析

2025年分产品/业务收入构成
<table><tr><td rowspan=1 colspan=1>产品/业务</td><td rowspan=1 colspan=1>收入（亿元）</td><td rowspan=1 colspan=1>收入占比</td><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>收入比上年增减</td></tr><tr><td rowspan=1 colspan=1>风电主轴承</td><td rowspan=1 colspan=1>39.35</td><td rowspan=1 colspan=1>61.0%</td><td rowspan=1 colspan=1>31.8%</td><td rowspan=1 colspan=1>+25.7%</td></tr><tr><td rowspan=1 colspan=1>齿轮箱零件</td><td rowspan=1 colspan=1>17.42</td><td rowspan=1 colspan=1>27.0%</td><td rowspan=1 colspan=1>27.6%</td><td rowspan=1 colspan=1>+21.9%</td></tr><tr><td rowspan=1 colspan=1>其他传动部件</td><td rowspan=1 colspan=1>7.73</td><td rowspan=1 colspan=1>12.0%</td><td rowspan=1 colspan=1>24.9%</td><td rowspan=1 colspan=1>+23.5%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>64.50</td><td rowspan=1 colspan=1>100.0%</td><td rowspan=1 colspan=1>30.2%</td><td rowspan=1 colspan=1>+24.5%</td></tr></table>

风电主轴承收入39.35亿元，同比增长25.7%，其中海上与大兆瓦产品收入占比达58%；齿轮箱零件收入17.42亿元，同比增长21.9%；其他传动部件收入7.73亿元，同比增长23.5%，矿山与海工场景贡献增量。

2025年分地区收入构成
<table><tr><td rowspan=1 colspan=1>地区</td><td rowspan=1 colspan=1>收入（亿元）</td><td rowspan=1 colspan=1>收入占比</td></tr><tr><td rowspan=1 colspan=1>境内</td><td rowspan=1 colspan=1>46.44</td><td rowspan=1 colspan=1>72.0%</td></tr><tr><td rowspan=1 colspan=1>境外</td><td rowspan=1 colspan=1>18.06</td><td rowspan=1 colspan=1>28.0%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>64.50</td><td rowspan=1 colspan=1>100.0%</td></tr></table>

注：前五名客户合计销售金额占年度销售总额的57.6%。

## 四、营业成本构成

营业成本构成（占营业成本比例)
<table><tr><td rowspan=1 colspan=1>成本项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>变动说明</td></tr><tr><td rowspan=1 colspan=1>特钢及锻件</td><td rowspan=1 colspan=1>44.6%</td><td rowspan=1 colspan=1>46.8%</td><td rowspan=1 colspan=1>与钢厂建立长协，采购价回落</td></tr><tr><td rowspan=1 colspan=1>辅助材料</td><td rowspan=1 colspan=1>12.2%</td><td rowspan=1 colspan=1>11.8%</td><td rowspan=1 colspan=1>保持架材料升级</td></tr><tr><td rowspan=1 colspan=1>直接人工</td><td rowspan=1 colspan=1>13.8%</td><td rowspan=1 colspan=1>13.4%</td><td rowspan=1 colspan=1>技能人才扩充</td></tr><tr><td rowspan=1 colspan=1>折旧及其他制造费用</td><td rowspan=1 colspan=1>29.4%</td><td rowspan=1 colspan=1>28.0%</td><td rowspan=1 colspan=1>大兆瓦产线转固</td></tr></table>

## 五、期间费用与研发投入

## 期间费用变动

<table><tr><td rowspan=1 colspan=1>费用项目</td><td rowspan=1 colspan=1>2025年（亿元）</td><td rowspan=1 colspan=1>2024年（亿元）</td><td rowspan=1 colspan=1>同比</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>2.20</td><td rowspan=1 colspan=1>1.90</td><td rowspan=1 colspan=1>+15.8%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>2.60</td><td rowspan=1 colspan=1>2.30</td><td rowspan=1 colspan=1>+13.0%</td></tr><tr><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>3.60</td><td rowspan=1 colspan=1>3.10</td><td rowspan=1 colspan=1>+16.1%</td></tr><tr><td rowspan=1 colspan=1>财务费用</td><td rowspan=1 colspan=1>0.30</td><td rowspan=1 colspan=1>0.42</td><td rowspan=1 colspan=1>-28.6%</td></tr></table>

研发投入方面，公司2025年研发投入合计3.60亿元，占营业收入比例5.6%，其中费用化研发费用3.60亿元、资本化研发投入0.00亿元；研发人员1,050人，占员工总数比例12.5%。

## 六、现金流量情况

现金流量主要项目
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年(亿元）</td><td rowspan=1 colspan=1>2024年(亿元）</td></tr><tr><td rowspan=1 colspan=1>经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>9.80</td><td rowspan=1 colspan=1>7.90</td></tr><tr><td rowspan=1 colspan=1>投资活动产生的现金流量净额</td><td rowspan=1 colspan=1>-11.60</td><td rowspan=1 colspan=1>-10.20</td></tr><tr><td rowspan=1 colspan=1>筹资活动产生的现金流量净额</td><td rowspan=1 colspan=1>3.20</td><td rowspan=1 colspan=1>0.80</td></tr></table>

报告期内经营活动现金流量净额9.80亿元，同比增长24.1%；投资活动净流出11.60亿元，主要投向大兆瓦主轴承产能与自贡二期建设；筹资活动净流入3.20亿元，来自绿色制造专项贷款。

## 七、资产及负债项目重大变动

## 资产、负债项目重大变动

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末(亿元)</td><td rowspan=1 colspan=1>期初（亿元）</td><td rowspan=1 colspan=1>变动比例</td><td rowspan=1 colspan=1>变动原因</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>14.60</td><td rowspan=1 colspan=1>11.80</td><td rowspan=1 colspan=1>+23.7%</td><td rowspan=1 colspan=1>经营积累及项目贷款到位</td></tr><tr><td rowspan=1 colspan=1>应收账款及应收票据</td><td rowspan=1 colspan=1>22.40</td><td rowspan=1 colspan=1>18.60</td><td rowspan=1 colspan=1>+20.4%</td><td rowspan=1 colspan=1>Q4交付放量</td></tr><tr><td rowspan=1 colspan=1>存货</td><td rowspan=1 colspan=1>14.80</td><td rowspan=1 colspan=1>12.20</td><td rowspan=1 colspan=1>+21.3%</td><td rowspan=1 colspan=1>海外订单备产</td></tr><tr><td rowspan=1 colspan=1>固定资产</td><td rowspan=1 colspan=1>62.40</td><td rowspan=1 colspan=1>55.80</td><td rowspan=1 colspan=1>+11.8%</td><td rowspan=1 colspan=1>大兆瓦产线投产转固</td></tr><tr><td rowspan=1 colspan=1>在建工程</td><td rowspan=1 colspan=1>6.20</td><td rowspan=1 colspan=1>9.80</td><td rowspan=1 colspan=1>-36.7%</td><td rowspan=1 colspan=1>自贡二期部分转固</td></tr></table>

## 八、公司未来发展的展望

2026年经营目标：营业收入80亿元左右，同比增长24%左右；出口收入占比提升至32%，完成20MW级漂浮式平台主轴承样件试制。

产能方面，自贡二期全面达产后大兆瓦主轴承年产能将达8,500套；公司同步启动墨西哥售后服务中心建设，完善全球交付与再制造网络。

## 九、风险因素

公司在本报告期及未来经营中可能面临以下主要风险，敬请投资者关注：

风电装机波动风险：国内风电装机受核准与电网消纳节奏影响较大，若装机不及预期将冲击主轴承需求。

价格竞争风险：风电整机价格持续下探并向供应链传导，零部件存在降价压力。

原材料风险：特钢价格波动影响毛利率与库存价值。

海上风电执行风险：海上项目交付周期长、质量要求高，执行瑕疵将影响回款与声誉。

汇率风险：出口收入占比上升，汇率波动影响利润与订单定价。

## 第五节 董事会报告

报告期内，公司共召开董事会会议9次、监事会会议4次、股东大会2次。公司董事会严格执行股东大会决议，勤勉尽责开展各项工作，2025年6月完成了上一年度利润分配方案的实施。

公司2025年度利润分配预案为：以实施权益分派股权登记日登记的总股本为基数，每10股派发现金红利1.20元(含税)，合计派发现金红利1.39亿元（含税)，占2025年度归属于上市公司股东净利润的22.38%。

公司2025年度财务报告审计机构为中衡会计师事务所(特殊普通合伙），报告期内公司不存在改聘、解聘会计师事务所的情形。公司已就2026年度财务报告审计服务续聘中衡会计师事务所（特殊普通合伙）并提请股东大会审议，审计收费180万元。

## 第六节 公司治理

报告期内，公司按照《公司法》《证券法》《上市公司治理准则》及公司章程的要求规范运作。公司董事会由9名董事组成，其中独立董事3名，占比不低于三分之一；监事会由3名监事组成，其中职工代表监事1名。董事会下设战略委员会、审计委员会、提名委员会、薪酬与考核委员会四个专门委员会，报告期内共召开专门委员会会议6次。

投资者关系方面，报告期内公司通过业绩说明会、投资者调研接待、互动平台答复等方式与投资者保持沟通，共接待机构投资者调研28批次，举办业绩说明会3次，回复互动平台提问120条。

内部控制方面，公司已建立覆盖全部业务流程的内部控制体系，报告期内未发现财务报告内部控制重大缺陷或重要缺陷。

## 第七节 环境、社会责任和其他公司治理

## 一、环境保护信息

## 环境信息主要指标

<table><tr><td rowspan=1 colspan=1>指标</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>同比变动</td></tr><tr><td rowspan=1 colspan=1>综合能耗（万吨标准煤）</td><td rowspan=1 colspan=1>7.45</td><td rowspan=1 colspan=1>+7.2%</td></tr><tr><td rowspan=1 colspan=1>温室气体排放范围一+二（万吨CO2e）</td><td rowspan=1 colspan=1>26.80</td><td rowspan=1 colspan=1>+6.4%</td></tr><tr><td rowspan=1 colspan=1>水资源消耗（万立方米）</td><td rowspan=1 colspan=1>96.5</td><td rowspan=1 colspan=1>+3.8%</td></tr><tr><td rowspan=1 colspan=1>环保投入（万元）</td><td rowspan=1 colspan=1>4,380</td><td rowspan=1 colspan=1>+17.0%</td></tr></table>

风电零部件制造天然关联减碳使命：报告期内公司主要基地屋顶光伏新增装机5MW，锻造余热回收系统投运后年节约标准煤约3,200吨，产品全生命周期碳足迹完成第三方核查。

## 二、社会责任

截至报告期末，公司员工总数8,400人，其中研发人员1,050人。报告期内公司持续完善职业发展通道与培训体系，人均培训时长24小时；全年对外捐赠及公益投入260万元，重点投向教育帮扶与乡村振兴领域。

## 三、公司治理专项情况

报告期内，公司控股股东、实际控制人不存在违规占用公司资金的情况，公司及控股子公司未发生违规对外担保。公司已披露ESG相关专项报告，详情见公司可持续发展报告。

## 第八节 重要事项

重大诉讼、仲裁事项：报告期内公司不存在重大诉讼、仲裁事项。

对外担保：报告期内公司不存在对外担保事项。

关联交易：报告期内公司日常关联交易合计260万元，为向参股热处理企业采购加工服务，程序合规。

承诺履行情况：公司控股股东、实际控制人及董监高报告期内不存在违反承诺情形。

重大合同：报告期内公司与两家海外整机厂签订2026-2028年主轴承及齿轮箱零件供货长协，合计约12.8亿元，已履行信息披露义务。

## 第九节 股份变动及股东情况

股份结构 (万股)
<table><tr><td rowspan=1 colspan=1>股份类别</td><td rowspan=1 colspan=1>数量（万股）</td><td rowspan=1 colspan=1>占总股本比例</td></tr><tr><td rowspan=1 colspan=1>无限售条件流通股</td><td rowspan=1 colspan=1>113,680.0</td><td rowspan=1 colspan=1>98.00%</td></tr><tr><td rowspan=1 colspan=1>限售股</td><td rowspan=1 colspan=1>2,320.0</td><td rowspan=1 colspan=1>2.00%</td></tr><tr><td rowspan=1 colspan=1>股份总数</td><td rowspan=1 colspan=1>116,000.0</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

## 前十大股东持股情况

## 截至2025年12月31日前十大股东

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>股东名称</td><td rowspan=1 colspan=1>持股比例</td><td rowspan=1 colspan=1>股东性质</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>铖重控股集团有限公司</td><td rowspan=1 colspan=1>16.80%</td><td rowspan=1 colspan=1>境内非国有法人</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>德阳重型装备产业投资集团</td><td rowspan=1 colspan=1>7.60%</td><td rowspan=1 colspan=1>国有法人</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>国能绿色能源产业基金</td><td rowspan=1 colspan=1>6.40%</td><td rowspan=1 colspan=1>国有法人</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>香港中央结算有限公司</td><td rowspan=1 colspan=1>4.20%</td><td rowspan=1 colspan=1>境外法人</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>泓峻海上风电基金（有限合伙）</td><td rowspan=1 colspan=1>3.80%</td><td rowspan=1 colspan=1>境内非国有法人</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>全国社保基金一零八组合</td><td rowspan=1 colspan=1>2.60%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>基本养老保险基金八零六组合</td><td rowspan=1 colspan=1>2.10%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>中证风电产业交易型指数基金</td><td rowspan=1 colspan=1>1.90%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>太平洋人寿保险- 万能险产品</td><td rowspan=1 colspan=1>1.50%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>铖励骨干员工持股计划</td><td rowspan=1 colspan=1>1.40%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>前十大股东合计</td><td rowspan=1 colspan=1>48.30%</td><td rowspan=1 colspan=1></td></tr></table>

公司控股股东为铖重控股集团有限公司，实际控制人为严啸崑家族。控股股东所持股份报告期内不存在质押、冻结情形。

## 第十节 财务报告

## 一、审计意见

公司2025年度财务报表业经中衡会计师事务所(特殊普通合伙)审计，并于2026年3月出具了标准无保留意见（中衡审字[2026]第0649号）。审计机构认为：公司财务报表在所有重大方面按照企业会计准则的规定编制，公允反映了公司2025年12月31日的合并及公司财务状况以及2025年度的合并及公司经营成果和现金流量。

## 二、合并资产负债表主要项目（摘要）

## 资产负债表主要项目

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末(亿元）</td><td rowspan=1 colspan=1>期初(亿元)</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>14.60</td><td rowspan=1 colspan=1>11.80</td></tr><tr><td rowspan=1 colspan=1>应收账款及应收票据</td><td rowspan=1 colspan=1>22.40</td><td rowspan=1 colspan=1>18.60</td></tr><tr><td rowspan=1 colspan=1>存货</td><td rowspan=1 colspan=1>14.80</td><td rowspan=1 colspan=1>12.20</td></tr><tr><td rowspan=1 colspan=1>固定资产</td><td rowspan=1 colspan=1>62.40</td><td rowspan=1 colspan=1>55.80</td></tr><tr><td rowspan=1 colspan=1>资产总计</td><td rowspan=1 colspan=1>158.40</td><td rowspan=1 colspan=1>142.60</td></tr><tr><td rowspan=1 colspan=1>短期借款</td><td rowspan=1 colspan=1>16.80</td><td rowspan=1 colspan=1>13.20</td></tr><tr><td rowspan=1 colspan=1>合同负债</td><td rowspan=1 colspan=1>3.10</td><td rowspan=1 colspan=1>2.60</td></tr><tr><td rowspan=1 colspan=1>其他负债</td><td rowspan=1 colspan=1>50.50</td><td rowspan=1 colspan=1>45.70</td></tr><tr><td rowspan=1 colspan=1>负债合计</td><td rowspan=1 colspan=1>70.40</td><td rowspan=1 colspan=1>61.50</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东权益合计</td><td rowspan=1 colspan=1>88.20</td><td rowspan=1 colspan=1>80.90</td></tr></table>

注：上述为合并口径主要项目摘要，完整资产负债表及附注以公司指定信息披露媒体披露的版本为准。

## 三、合并利润表主要项目（摘要)

## 利润表主要项目

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年(亿元）</td><td rowspan=1 colspan=1>2024年(亿元）</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>64.50</td><td rowspan=1 colspan=1>51.80</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>45.02</td><td rowspan=1 colspan=1>36.57</td></tr><tr><td rowspan=1 colspan=1>期间费用合计</td><td rowspan=1 colspan=1>8.70</td><td rowspan=1 colspan=1>7.72</td></tr><tr><td rowspan=1 colspan=1>研发费用（含于期间费用）</td><td rowspan=1 colspan=1>3.60</td><td rowspan=1 colspan=1>3.10</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的净利润</td><td rowspan=1 colspan=1>6.21</td><td rowspan=1 colspan=1>4.63</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的扣除非经常性损益的净利润</td><td rowspan=1 colspan=1>5.58</td><td rowspan=1 colspan=1>4.16</td></tr></table>

## 四、合并现金流量表主要项目（摘要)

现金流量表主要项目
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年(亿元）</td><td rowspan=1 colspan=1>2024年(亿元)</td></tr><tr><td rowspan=1 colspan=1>经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>9.80</td><td rowspan=1 colspan=1>7.90</td></tr><tr><td rowspan=1 colspan=1>投资活动产生的现金流量净额</td><td rowspan=1 colspan=1>-11.60</td><td rowspan=1 colspan=1>-10.20</td></tr><tr><td rowspan=1 colspan=1>筹资活动产生的现金流量净额</td><td rowspan=1 colspan=1>3.20</td><td rowspan=1 colspan=1>0.80</td></tr></table>

公司执行财政部颁布的企业会计准则及相关规定，主要会计政策与上一年度保持一致，报告期内无重大会计估计变更。

## 备查文件目录

载有公司法定代表人、主管会计工作负责人、会计机构负责人签名并盖章的财务报表。

载有会计师事务所盖章、注册会计师签名并盖章的2025年度审计报告原件。

·报告期内公开披露过的所有公司文件的正本及公告原稿。

公司2025年年度股东大会会议资料及决议。

(本报告为模拟数据，仅供研究测试使用，不构成任何投资建议)