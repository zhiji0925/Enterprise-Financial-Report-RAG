# 苏州醇安医疗器械股份有限公司

2025年年度报告

(股票简称：醇安医疗股票代码：300781.SZ)(深圳证券交易所创业板)

披露日期：2026年4月10日

公司统一社会信用代码：91320594MA25Q1N6YT

## 重要提示

一、公司董事会、监事会及董事、监事、高级管理人员保证年度报告内容的真实、准确、完整，不存在虚假记载、误导性陈述或重大遗漏，并承担个别和连带的法律责任。

二、公司2025年度利润分配预案为：以实施权益分派股权登记日登记的总股本为基数，每10股派发现金红利4.00元（含税），合计派发现金红利1.92亿元(含税)，占2025年度归属于上市公司股东净利润的31.89%。该预案尚需提交公司2025年年度股东大会审议。

三、公司全体董事出席了审议本次年度报告的董事会会议，会议以9票同意、0票反对、0票弃权审议通过了本报告。

四、公司2025年度财务报告已经中衡会计师事务所（特殊普通合伙）审计，并出具了标准无保留意见审计报告(中衡审字[2026]第0312号)。

五、本报告所载未来计划、经营目标等前瞻性陈述不构成公司对投资者的实质性承诺，投资者应当对此保持足够的风险认识。

六、报告期内，不存在控股股东及其关联方非经营性占用公司资金的情况。

七、报告期内，公司不存在违反规定程序对外提供担保的情况。

八、公司负责人程书堂、主管会计工作负责人冉静姝及会计机构负责人（财务部部长）保证本报告中财务报告的真实、准确、完整。

九、敬请投资者认真阅读本报告第四节'管理层讨论与分析'中'风险因素'部分的内容，充分关注公司经营中可能面临的相关风险。

重要提示  
第一节释义  
第二节 致股东的信  
第三节公司简介和主要财务指标  
第四节管理层讨论与分析  
第五节 董事会报告  
第六节公司治理  
第七节环境、社会责任和其他公司治理  
第八节 重要事项  
第九节股份变动及股东情况  
第十节财务报告  
备查文件目录

## 目录

## 第一节释义

## 释义表

<table><tr><td rowspan=1 colspan=1>术语/简称</td><td rowspan=1 colspan=1>释义</td></tr><tr><td rowspan=1 colspan=1>公司、醇安医疗</td><td rowspan=1 colspan=1>指苏州醇安医疗器械股份有限公司</td></tr><tr><td rowspan=1 colspan=1>骨科植入耗材</td><td rowspan=1 colspan=1>指植入人体用于骨折固定、脊柱矫形、韧带修复等治疗的医疗器械</td></tr><tr><td rowspan=1 colspan=1>带线锚钉</td><td rowspan=1 colspan=1>指运动医学手术中将缝线固定于骨质的植入物</td></tr><tr><td rowspan=1 colspan=1>椎体成形</td><td rowspan=1 colspan=1>指向病变椎体内注入骨水泥以稳定椎体的微创术式</td></tr><tr><td rowspan=1 colspan=1>集采续约</td><td rowspan=1 colspan=1>指集中带量采购协议期满后就下一采购周期的再次招标</td></tr><tr><td rowspan=1 colspan=1>运动医学</td><td rowspan=1 colspan=1>指针对关节、韧带、软骨等运动系统损伤的诊疗领域</td></tr><tr><td rowspan=1 colspan=1>EPD/电动工具</td><td rowspan=1 colspan=1>指手术中使用的电池动力手术器械系统</td></tr><tr><td rowspan=1 colspan=1>MDR</td><td rowspan=1 colspan=1>指欧盟医疗器械法规新的注册监管体系</td></tr></table>

## 第二节 致股东的信

2025年，骨科耗材行业完成了从'集采冲击'到'量价修复'的转折。醇安医疗实现营业收入31.20亿元，同比增长19.5%；归属于上市公司股东的净利润6.02亿元，同比增长12.5%；综合毛利率62.5%，恢复到集采前的最好水平之上。

这一年，公司做了三件正确的事：一是抓集采续约的窗口，创伤与脊柱主力产品全线中选且价格企稳；二是把运动医学做成第二增长曲线，收入同比增长31.7%，带线锚钉与全缝合修复产品进入400余家核心医院；三是坚持出海，境外收入占比提升至14.0%，在东南亚与中东建立本地化经销商体系。

骨科的竞争力最终是'产品+手术服务能力'的竞争。2026年，公司将推进3D打印定制化假体注册与机器人辅助手术工具生态，把创新产品收入占比提升到25%以上。感谢每一位信任醇安的股东与临床伙伴。

董事长：程书堂2026年3月

## 第三节 公司简介和主要财务指标

## 一、公司基本情况

公司基本情况
<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">内容</td></tr><tr><td colspan="1" rowspan="1">公司中文全称</td><td colspan="1" rowspan="1">苏州醇安医疗器械股份有限公司</td></tr><tr><td colspan="1" rowspan="1">证券简称</td><td colspan="1" rowspan="1">醇安医疗</td></tr><tr><td colspan="1" rowspan="1">证券代码</td><td colspan="1" rowspan="1">300781.SZ</td></tr><tr><td colspan="1" rowspan="1">上市板块</td><td colspan="1" rowspan="1">深圳证券交易所创业板</td></tr><tr><td colspan="1" rowspan="1">注册地/总部</td><td colspan="1" rowspan="1">江苏省苏州市工业园区</td></tr><tr><td colspan="1" rowspan="1">上市时间</td><td colspan="1" rowspan="1">2021年3月</td></tr><tr><td colspan="1" rowspan="1">所处行业</td><td colspan="1" rowspan="1">医疗器械（骨科植入耗材）</td></tr><tr><td colspan="1" rowspan="1">董事长</td><td colspan="1" rowspan="1">程书堂</td></tr><tr><td colspan="1" rowspan="1">总经理</td><td colspan="1" rowspan="1">白清越</td></tr><tr><td colspan="1" rowspan="1">董事会秘书</td><td colspan="1" rowspan="1">冉静姝</td></tr><tr><td colspan="1" rowspan="1">审计机构</td><td colspan="1" rowspan="1">中衡会计师事务所(特殊普通合伙)</td></tr><tr><td colspan="1" rowspan="1">员工总数（人）</td><td colspan="1" rowspan="1">5,600</td></tr></table>

## 二、公司历史沿革

公司成立于2005年，总部位于苏州，2021年3月在深圳证券交易所创业板上市，是国内骨科植入耗材领域的头部企业之一，产品覆盖创伤、脊柱、运动医学三大产品线。

截至报告期末，公司取得医疗器械注册证138项，其中国家三类证52项；建有苏州与常州两个生产与灭菌基地，年产植入物能力1,100万件。

## 三、主要会计数据和财务指标

近三年主要会计数据和财务指标
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>本年比上年增减</td><td rowspan=1 colspan=1>2023年</td></tr><tr><td rowspan=1 colspan=1>营业收入(亿元)</td><td rowspan=1 colspan=1>31.20</td><td rowspan=1 colspan=1>26.10</td><td rowspan=1 colspan=1>+19.5%</td><td rowspan=1 colspan=1>22.60</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润（亿元）</td><td rowspan=1 colspan=1>6.02</td><td rowspan=1 colspan=1>5.35</td><td rowspan=1 colspan=1>+12.5%</td><td rowspan=1 colspan=1>4.72</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的扣除非经常性损益的净利润 (亿元)</td><td rowspan=1 colspan=1>5.48</td><td rowspan=1 colspan=1>4.96</td><td rowspan=1 colspan=1>+10.5%</td><td rowspan=1 colspan=1>4.38</td></tr><tr><td rowspan=1 colspan=1>经营活动产生的现金流量净额（亿元）</td><td rowspan=1 colspan=1>7.20</td><td rowspan=1 colspan=1>5.50</td><td rowspan=1 colspan=1>+30.9%</td><td rowspan=1 colspan=1>4.80</td></tr><tr><td rowspan=1 colspan=1>基本每股收益（元/股）</td><td rowspan=1 colspan=1>1.25</td><td rowspan=1 colspan=1>1.11</td><td rowspan=1 colspan=1>+12.5%</td><td rowspan=1 colspan=1>0.98</td></tr><tr><td rowspan=1 colspan=1>加权平均净资产收益率（%)</td><td rowspan=1 colspan=1>14.20</td><td rowspan=1 colspan=1>13.00</td><td rowspan=1 colspan=1>增加1.20个百分点</td><td rowspan=1 colspan=1>11.90</td></tr><tr><td rowspan=1 colspan=1>总资产 (亿元)</td><td rowspan=1 colspan=1>58.60</td><td rowspan=1 colspan=1>56.80</td><td rowspan=1 colspan=1>+3.2%</td><td rowspan=1 colspan=1>一</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净资产（亿元）</td><td rowspan=1 colspan=1>43.90</td><td rowspan=1 colspan=1>40.90</td><td rowspan=1 colspan=1>+7.3%</td><td rowspan=1 colspan=1></td></tr></table>

注：除特别注明外，金额单位均为人民币亿元；净资产收益率口径为加权平均。

## 四、非经常性损益项目及金额

2025年非经常性损益项目明细
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>金额（亿元)</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>计入当期损益的政府补助</td><td rowspan=1 colspan=1>0.20</td><td rowspan=1 colspan=1>高端医疗器械产业化专项</td></tr><tr><td rowspan=1 colspan=1>理财收益</td><td rowspan=1 colspan=1>0.14</td><td rowspan=1 colspan=1>闲置募集资金现金管理</td></tr><tr><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1>0.20</td><td rowspan=1 colspan=1>增值税加计抵减及资产处置收益</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>0.54</td><td rowspan=1 colspan=1>占归母净利润比例 9.0%</td></tr></table>

非经常性损益项目数据来源：公司财务报表附注，并经审计确认。

## 五、分季度主要财务数据

2025年分季度主要财务数据
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>第一季度</td><td rowspan=1 colspan=1>第二季度</td><td rowspan=1 colspan=1>第三季度</td><td rowspan=1 colspan=1>第四季度</td></tr><tr><td rowspan=1 colspan=1>营业收入（亿元）</td><td rowspan=1 colspan=1>7.00</td><td rowspan=1 colspan=1>7.60</td><td rowspan=1 colspan=1>8.10</td><td rowspan=1 colspan=1>8.50</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润(亿元)</td><td rowspan=1 colspan=1>1.32</td><td rowspan=1 colspan=1>1.44</td><td rowspan=1 colspan=1>1.56</td><td rowspan=1 colspan=1>1.70</td></tr></table>

## 第四节 管理层讨论与分析

## 一、报告期内公司所处行业情况

骨科耗材集采在主要标全面落地后进入'后集采'时代，2025年多省创伤、脊柱集采续约报价趋于理性，中标价格降幅明显收窄，行业进入量价修复期。2025年国内骨科植入物市场规模约360亿元，同比增长约15%。

需求端，人口老龄化与运动损伤年轻化共同驱动手术量增长；供给端，行业格局重塑后头部企业份额提升，创新产品（3D打印、数字化手术工具、生物材料）成为新的竞争焦点。海外新兴市场对中国骨科产品的接受度持续提高。

图1：2022-2025年公司综合毛利率(%）  
![](images/a012ed9d314d07d6a4afa3dac02e188dd557b097713f5c74d42fd354c187f6b2.jpg)  
资料来源：公司历年年度报告；2023年为集采全面落地冲击年，2024年起量价修复

## 二、报告期内公司从事的主要业务

公司主营业务为骨科植入耗材及配套手术工具的研发、生产与销售，主要产品覆盖创伤接骨板/髓内钉、脊柱椎弓根螺钉/融合器、运动医学锚钉/缝线等，并为医疗机构提供全流程手术配套服务。

报告期内，公司集采主力产品在13个省级续约标的中全线中选；3D打印椎间融合器取得三类注册证，成为国产首批获批的同代产品；海外在巴西、沙特完成两款脊柱产品注册。

## 三、营业收入构成及变动分析

2025年分产品/业务收入构成
<table><tr><td rowspan=1 colspan=1>产品/业务</td><td rowspan=1 colspan=1>收入（亿元）</td><td rowspan=1 colspan=1>收入占比</td><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>收入比上年增减</td></tr><tr><td rowspan=1 colspan=1>创伤类产品</td><td rowspan=1 colspan=1>14.98</td><td rowspan=1 colspan=1>48.0%</td><td rowspan=1 colspan=1>60.5%</td><td rowspan=1 colspan=1>+16.6%</td></tr><tr><td rowspan=1 colspan=1>脊柱类产品</td><td rowspan=1 colspan=1>9.04</td><td rowspan=1 colspan=1>29.0%</td><td rowspan=1 colspan=1>63.8%</td><td rowspan=1 colspan=1>+15.9%</td></tr><tr><td rowspan=1 colspan=1>运动医学类产品</td><td rowspan=1 colspan=1>7.18</td><td rowspan=1 colspan=1>23.0%</td><td rowspan=1 colspan=1>64.2%</td><td rowspan=1 colspan=1>+31.7%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>31.20</td><td rowspan=1 colspan=1>100.0%</td><td rowspan=1 colspan=1>62.5%</td><td rowspan=1 colspan=1>+19.5%</td></tr></table>

创伤类产品收入14.98亿元，同比增长16.6%，量价修复驱动明显；脊柱类产品收入9.04亿元，同比增长15.9%，3D打印融合器贡献增量；运动医学类产品收入7.18亿元，同比增长31.7%，是公司成长最快的板块。

## 图2：2023-2025年分板块营业收入（亿元）

![](images/b9a5ddc828049feddcfd9546a31c59da02ff2f2ace40b164051f65ca95a2405c.jpg)  
资料来源：公司2025年年度报告

2025年分地区收入构成
<table><tr><td rowspan=1 colspan=1>地区</td><td rowspan=1 colspan=1>收入(亿元）</td><td rowspan=1 colspan=1>收入占比</td></tr><tr><td rowspan=1 colspan=1>境内</td><td rowspan=1 colspan=1>26.83</td><td rowspan=1 colspan=1>86.0%</td></tr><tr><td rowspan=1 colspan=1>境外</td><td rowspan=1 colspan=1>4.37</td><td rowspan=1 colspan=1>14.0%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>31.20</td><td rowspan=1 colspan=1>100.0%</td></tr></table>

注：前五名客户合计销售金额占年度销售总额的23.8%。

## 四、营业成本构成

营业成本构成（占营业成本比例）
<table><tr><td rowspan=1 colspan=1>成本项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>变动说明</td></tr><tr><td rowspan=1 colspan=1>钛材及植入物原材料</td><td rowspan=1 colspan=1>41.5%</td><td rowspan=1 colspan=1>44.2%</td><td rowspan=1 colspan=1>钛材价格回落与工艺良率提升</td></tr><tr><td rowspan=1 colspan=1>灭菌包装及耗材</td><td rowspan=1 colspan=1>18.6%</td><td rowspan=1 colspan=1>18.0%</td><td rowspan=1 colspan=1>自建灭菌中心投产</td></tr><tr><td rowspan=1 colspan=1>人工及制造费用</td><td rowspan=1 colspan=1>39.9%</td><td rowspan=1 colspan=1>37.8%</td><td rowspan=1 colspan=1>常州基地产能爬坡</td></tr></table>

## 五、期间费用与研发投入

期间费用变动
<table><tr><td rowspan=1 colspan=1>费用项目</td><td rowspan=1 colspan=1>2025年（亿元）</td><td rowspan=1 colspan=1>2024年（亿元）</td><td rowspan=1 colspan=1>同比</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>5.85</td><td rowspan=1 colspan=1>5.10</td><td rowspan=1 colspan=1>+14.7%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>2.60</td><td rowspan=1 colspan=1>2.40</td><td rowspan=1 colspan=1>+8.3%</td></tr><tr><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>2.10</td><td rowspan=1 colspan=1>1.85</td><td rowspan=1 colspan=1>+13.5%</td></tr><tr><td rowspan=1 colspan=1>财务费用</td><td rowspan=1 colspan=1>-0.18</td><td rowspan=1 colspan=1>-0.15</td><td rowspan=1 colspan=1>+20.0%</td></tr></table>

研发投入方面，公司2025年研发投入合计2.35亿元，占营业收入比例7.5%，其中费用化研发费用2.10亿元、资本化研发投入0.25亿元；研发人员1,020人，占员工总数比例18.2%。

## 六、现金流量情况

## 现金流量主要项目

<table><tr><td rowspan=2 colspan=1>项目经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>2025年(亿元）</td><td rowspan=1 colspan=1>2024年(亿元）</td></tr><tr><td rowspan=1 colspan=1>7.20</td><td rowspan=1 colspan=1>5.50</td></tr><tr><td rowspan=1 colspan=1>投资活动产生的现金流量净额</td><td rowspan=1 colspan=1>-2.40</td><td rowspan=1 colspan=1>-2.00</td></tr><tr><td rowspan=1 colspan=1>筹资活动产生的现金流量净额</td><td rowspan=1 colspan=1>0.80</td><td rowspan=1 colspan=1>1.20</td></tr></table>

报告期内经营活动现金流量净额7.20亿元，同比增长30.9%，集采结算方式下回款确定性增强；投资活动净流出2.40亿元；筹资活动净流入0.80亿元。

## 七、资产及负债项目重大变动

资产、负债项目重大变动
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末(亿元)</td><td rowspan=1 colspan=1>期初(亿元)</td><td rowspan=1 colspan=1>变动比例</td><td rowspan=1 colspan=1>变动原因</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>12.80</td><td rowspan=1 colspan=1>13.20</td><td rowspan=1 colspan=1>-3.0%</td><td rowspan=1 colspan=1>经营积累，理财结构调节</td></tr><tr><td rowspan=1 colspan=1>固定资产及在建工程</td><td rowspan=1 colspan=1>18.60</td><td rowspan=1 colspan=1>16.50</td><td rowspan=1 colspan=1>+12.7%</td><td rowspan=1 colspan=1>常州运动医学产线投入</td></tr><tr><td rowspan=1 colspan=1>应收账款及合同资产</td><td rowspan=1 colspan=1>9.60</td><td rowspan=1 colspan=1>9.80</td><td rowspan=1 colspan=1>-2.0%</td><td rowspan=1 colspan=1>集采回款账期稳定</td></tr></table>

## 八、公司未来发展的展望

2026年经营目标：营业收入37亿元左右，同比增长约19%；运动医学收入突破9亿元，境外收入占比提升至17%；推进手术机器人配套工具注册与骨科数字化平台商业化。

产能方面，常州运动医学二期产线将于2026年上半年投产，新增锚钉年产能60万件；公司将建设骨科3D打印定制化服务中心，缩短定制假体交付周期至7天。

## 九、风险因素

公司在本报告期及未来经营中可能面临以下主要风险，敬请投资者关注：

集采价格风险：若未来续约集采降价超预期或集采范围扩大，公司主力产品价格与盈利能力将受影响。

产品结构风险：公司收入集中于骨科单一领域，跨赛道布局尚在培育期。

海外注册风险：境外认证周期长、投入大，MDR等法规变化可能影响出海进度。

经销商管理风险：公司以经销为主，渠道库存与终端价格秩序存在管理挑战。

研发转化风险：创新产品注册临床周期长，投入产出存在不确定性。

## 第五节 董事会报告

报告期内，公司共召开董事会会议9次、监事会会议5次、股东大会2次。公司董事会严格执行股东大会决议，勤勉尽责开展各项工作，2025年6月完成了上一年度利润分配方案的实施。

公司2025年度利润分配预案为：以实施权益分派股权登记日登记的总股本为基数，每10股派发现金红利4.00元（含税)，合计派发现金红利1.92亿元（含税)，占2025年度归属于上市公司股东净利润的31.89%。

公司2025年度财务报告审计机构为中衡会计师事务所(特殊普通合伙)，报告期内公司不存在改聘、解聘会计师事务所的情形。公司已就2026年度财务报告审计服务续聘中衡会计师事务所（特殊普通合伙）并提请股东大会审议，审计收费180万元。

## 第六节 公司治理

报告期内，公司按照《公司法》《证券法》《上市公司治理准则》及公司章程的要求规范运作。公司董事会由9名董事组成，其中独立董事3名，占比不低于三分之一；监事会由3名监事组成，其中职工代表监事1名。董事会下设战略委员会、审计委员会、提名委员会、薪酬与考核委员会四个专门委员会，报告期内共召开专门委员会会议6次。

投资者关系方面，报告期内公司通过业绩说明会、投资者调研接待、互动平台答复等方式与投资者保持沟通，共接待机构投资者调研28批次，举办业绩说明会3次，回复互动平台提问120条。

内部控制方面，公司已建立覆盖全部业务流程的内部控制体系，报告期内未发现财务报告内部控制重大缺陷或重要缺陷。

## 第七节环境、社会责任和其他公司治理

## 一、环境保护信息

## 环境信息主要指标

<table><tr><td rowspan=1 colspan=1>指标</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>同比变动</td></tr><tr><td rowspan=1 colspan=1>医疗废物规范化处置率</td><td rowspan=1 colspan=1>100%</td><td rowspan=1 colspan=1>持平</td></tr><tr><td rowspan=1 colspan=1>综合能耗 (吨标准煤)</td><td rowspan=1 colspan=1>12,600</td><td rowspan=1 colspan=1>+2.1%</td></tr><tr><td rowspan=1 colspan=1>温室气体排放范围一+二（吨CO2e）</td><td rowspan=1 colspan=1>30,200</td><td rowspan=1 colspan=1>+2.8%</td></tr><tr><td rowspan=1 colspan=1>环保投入（万元)</td><td rowspan=1 colspan=1>360</td><td rowspan=1 colspan=1>+12.0%</td></tr></table>

公司在行业内较早推行植入物可追溯UDI系统全覆盖，报告期内对11家上游供应商完成社会责任审核

## 二、社会责任

截至报告期末，公司员工总数5,600人，其中研发人员1,020人。报告期内公司持续完善职业发展通道与培训体系，人均培训时长24小时；全年对外捐赠及公益投入260万元，重点投向教育帮扶与乡村振兴领域。

## 三、公司治理专项情况

报告期内，公司控股股东、实际控制人不存在违规占用公司资金的情况，公司及控股子公司未发生违规对外担保。公司已披露ESG相关专项报告，详情见公司可持续发展报告

## 第八节 重要事项

集采中标情况：报告期内公司参与13个省级骨科耗材集采续约项目并全线中选，价格降幅与上一采购周期相比明显收窄。

重大诉讼、仲裁事项：报告期内公司不存在重大诉讼、仲裁事项。

对外担保：报告期内公司不存在对外担保事项。

关联交易：报告期内公司与关联方发生的日常关联交易合计金额为95万元，程序合规

股权激励：报告期内公司实施2025年第二期限制性股票激励计划，向112名核心技术与营销人员授予260万股，考核目标为2026-2028年营业收入复合增长率不低于15%。

## 第九节 股份变动及股东情况

股份结构 (万股)

<table><tr><td rowspan=1 colspan=1>股份类别</td><td rowspan=1 colspan=1>数量(万股)</td><td rowspan=1 colspan=1>占总股本比例</td></tr><tr><td rowspan=1 colspan=1>无限售条件流通股</td><td rowspan=1 colspan=1>37,440.0</td><td rowspan=1 colspan=1>78.00%</td></tr><tr><td rowspan=1 colspan=1>限售股</td><td rowspan=1 colspan=1>10,560.0</td><td rowspan=1 colspan=1>22.00%</td></tr><tr><td rowspan=1 colspan=1>股份总数</td><td rowspan=1 colspan=1>48,000.0</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

## 前十大股东持股情况

## 截至2025年12月31日前十大股东

<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>股东名称</td><td rowspan=1 colspan=1>持股比例</td><td rowspan=1 colspan=1>股东性质</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>醇安控股集团有限公司</td><td rowspan=1 colspan=1>26.40%</td><td rowspan=1 colspan=1>境内非国有法人</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>苏州工业园区科创基金（有限合伙)</td><td rowspan=1 colspan=1>7.20%</td><td rowspan=1 colspan=1>国有法人</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>香港中央结算有限公司</td><td rowspan=1 colspan=1>5.60%</td><td rowspan=1 colspan=1>境外法人</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>国药资本医疗产业基金</td><td rowspan=1 colspan=1>4.10%</td><td rowspan=1 colspan=1>境内非国有法人</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>全国社保基金——四组合</td><td rowspan=1 colspan=1>3.30%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>基本养老保险基金八零六组合</td><td rowspan=1 colspan=1>2.60%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>泰康人寿保险一分红险产品</td><td rowspan=1 colspan=1>2.10%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>醇安员工持股计划</td><td rowspan=1 colspan=1>1.60%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>易方达创业板ETF</td><td rowspan=1 colspan=1>1.30%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>招商国证生物医药指数基金</td><td rowspan=1 colspan=1>1.05%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>前十大股东合计</td><td rowspan=1 colspan=1>55.25%</td><td rowspan=1 colspan=1></td></tr></table>

公司控股股东为醇安控股集团有限公司，实际控制人为程书堂。控股股东所持股份报告期内不存在质押、冻结情形。

## 第十节 财务报告

## 一、审计意见

公司2025年度财务报表业经中衡会计师事务所(特殊普通合伙）审计，并于2026年3月出具了标准无保留意见（中衡审字[2026]第0312号）。审计机构认为：公司财务报表在所有重大方面按照企业会计准则的规定编制，公允反映了公司2025年12月31日的合并及公司财务状况以及2025年度的合并及公司经营成果和现金流量。

## 二、合并资产负债表主要项目（摘要)

## 资产负债表主要项目

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">期末（亿元)</td><td colspan="1" rowspan="1">期初(亿元)</td></tr><tr><td colspan="1" rowspan="1">货币资金</td><td colspan="1" rowspan="1">12.80</td><td colspan="1" rowspan="1">13.20</td></tr><tr><td colspan="1" rowspan="1">应收账款及合同资产</td><td colspan="1" rowspan="1">9.60</td><td colspan="1" rowspan="1">9.80</td></tr><tr><td colspan="1" rowspan="1">存货</td><td colspan="1" rowspan="1">6.40</td><td colspan="1" rowspan="1">6.10</td></tr><tr><td colspan="1" rowspan="1">固定资产及在建工程</td><td colspan="1" rowspan="1">18.60</td><td colspan="1" rowspan="1">16.50</td></tr><tr><td colspan="1" rowspan="1">其他资产</td><td colspan="1" rowspan="1">11.20</td><td colspan="1" rowspan="1">11.20</td></tr><tr><td colspan="1" rowspan="1">资产总计</td><td colspan="1" rowspan="1">58.60</td><td colspan="1" rowspan="1">56.80</td></tr><tr><td colspan="1" rowspan="1">应付账款及应付票据</td><td colspan="1" rowspan="1">5.60</td><td colspan="1" rowspan="1">6.20</td></tr><tr><td colspan="1" rowspan="1">合同负债</td><td colspan="1" rowspan="1">1.30</td><td colspan="1" rowspan="1">1.40</td></tr><tr><td colspan="1" rowspan="1">借款及其他负债</td><td colspan="1" rowspan="1">7.80</td><td colspan="1" rowspan="1">8.30</td></tr><tr><td colspan="1" rowspan="1">负债合计</td><td colspan="1" rowspan="1">14.70</td><td colspan="1" rowspan="1">15.90</td></tr><tr><td colspan="1" rowspan="1">归属于母公司股东权益合计</td><td colspan="1" rowspan="1">43.90</td><td colspan="1" rowspan="1">40.90</td></tr></table>

注：上述为合并口径主要项目摘要，完整资产负债表及附注以公司指定信息披露媒体披露的版本为准。

## 三、合并利润表主要项目（摘要)

## 利润表主要项目

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年(亿元）</td><td rowspan=1 colspan=1>2024年(亿元）</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>31.20</td><td rowspan=1 colspan=1>26.10</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>11.70</td><td rowspan=1 colspan=1>10.23</td></tr><tr><td rowspan=1 colspan=1>期间费用合计</td><td rowspan=1 colspan=1>10.37</td><td rowspan=1 colspan=1>9.20</td></tr><tr><td rowspan=1 colspan=1>研发费用（含于期间费用）</td><td rowspan=1 colspan=1>2.10</td><td rowspan=1 colspan=1>1.85</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的净利润</td><td rowspan=1 colspan=1>6.02</td><td rowspan=1 colspan=1>5.35</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的扣除非经常性损益的净利润</td><td rowspan=1 colspan=1>5.48</td><td rowspan=1 colspan=1>4.96</td></tr></table>

## 四、合并现金流量表主要项目（摘要)

现金流量表主要项目
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年(亿元）</td><td rowspan=1 colspan=1>2024年(亿元）</td></tr><tr><td rowspan=1 colspan=1>经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>7.20</td><td rowspan=1 colspan=1>5.50</td></tr><tr><td rowspan=1 colspan=1>投资活动产生的现金流量净额</td><td rowspan=1 colspan=1>-2.40</td><td rowspan=1 colspan=1>-2.00</td></tr><tr><td rowspan=1 colspan=1>筹资活动产生的现金流量净额</td><td rowspan=1 colspan=1>0.80</td><td rowspan=1 colspan=1>1.20</td></tr></table>

公司执行财政部颁布的企业会计准则及相关规定，主要会计政策与上一年度保持一致，报告期内无重大会计估计变更。

## 备查文件目录

载有公司法定代表人、主管会计工作负责人、会计机构负责人签名并盖章的财务报表。

载有会计师事务所盖章、注册会计师签名并盖章的2025年度审计报告原件。

·报告期内公开披露过的所有公司文件的正本及公告原稿。

公司2025年年度股东大会会议资料及决议。

(本报告为模拟数据，仅供研究测试使用，不构成任何投资建议)