# 杭州璞兰诊断技术股份有限公司

2025年年度报告

(股票简称：璞兰诊断股票代码：301566.SZ)(深圳证券交易所创业板)

披露日期：2026年4月12日

公司统一社会信用代码：91330106MA2H15W7QN

## 重要提示

一、公司董事会、监事会及董事、监事、高级管理人员保证年度报告内容的真实、准确、完整，不存在虚假记载、误导性陈述或重大遗漏，并承担个别和连带的法律责任。

二、公司2025年度利润分配预案为：以实施权益分派股权登记日登记的总股本为基数，每10股派发现金红利3.50元(含税)，合计派发现金红利1.54亿元（含税)，占2025年度归属于上市公司股东净利润的29.00%。该预案尚需提交公司2025年年度股东大会审议。

三、公司全体董事出席了审议本次年度报告的董事会会议，会议以9票同意、0票反对、0票弃权审议通过了本报告。

四、公司2025年度财务报告已经中允会计师事务所（特殊普通合伙）审计，并出具了标准无保留意见审计报告(中允审字[2026]第0234号）。

五、本报告所载未来计划、经营目标等前瞻性陈述不构成公司对投资者的实质性承诺，投资者应当对此保持足够的风险认识。

六、报告期内，不存在控股股东及其关联方非经营性占用公司资金的情况。

七、报告期内，公司不存在违反规定程序对外提供担保的情况。

八、公司负责人桂怀璞、主管会计工作负责人满庭芳及会计机构负责人（财务部部长）保证本报告中财务报告的真实、准确、完整。

九、敬请投资者认真阅读本报告第四节'管理层讨论与分析'中'风险因素'部分的内容，充分关注公司经营中可能面临的相关风险。

重要提示  
第一节释义  
第二节 致股东的信  
第三节公司简介和主要财务指标  
第四节 管理层讨论与分析  
第五节 董事会报告  
第六节公司治理  
第七节环境、社会责任和其他公司治理  
第八节 重要事项  
第九节股份变动及股东情况  
第十节财务报告  
备查文件目录

## 目录

## 第一节释义

## 释义表

<table><tr><td rowspan=1 colspan=1>术语/简称</td><td rowspan=1 colspan=1>释义</td></tr><tr><td rowspan=1 colspan=1>公司、璞兰诊断</td><td rowspan=1 colspan=1>指杭州璞兰诊断技术股份有限公司</td></tr><tr><td rowspan=1 colspan=1>IVD</td><td rowspan=1 colspan=1>指体外诊断，即在人体外对样本进行检测的医疗手段</td></tr><tr><td rowspan=1 colspan=1>化学发光</td><td rowspan=1 colspan=1>指以化学发光信号标记免疫反应的检测技术</td></tr><tr><td rowspan=1 colspan=1>流水线</td><td rowspan=1 colspan=1>指将前处理、检测、后处理自动化的检验分析系统</td></tr><tr><td rowspan=1 colspan=1>肿标</td><td rowspan=1 colspan=1>指肿瘤标志物检测项目</td></tr><tr><td rowspan=1 colspan=1>集采 (试剂)</td><td rowspan=1 colspan=1>指对诊断试剂实施的价格治理与集中采购机制</td></tr><tr><td rowspan=1 colspan=1>封闭系统</td><td rowspan=1 colspan=1>指仪器与试剂配套使用的商业模式</td></tr><tr><td rowspan=1 colspan=1>二类/三类证</td><td rowspan=1 colspan=1>指医疗器械注册证的管理类别</td></tr></table>

## 第二节 致股东的信

2025年，体外诊断行业走出了价格治理的阴霾，璞兰诊断实现营业收入28.40亿元，同比增长19.3%；归属于上市公司股东的净利润5.31亿元，同比增长11.1%；期末化学发光仪器累计装机3,850台，跻身国产第一梯队。

这一年，发光试剂集采规则温和落地，公司在安徽等首发联盟以价换量，中标项目入院放量超预期；高速发光仪P-L8000完成三代升级，单机测试速度提升至300测试/小时；流水线业务签约42条，成为高端市场突破的支点。

诊断的价值在于让检验结果更早、更准、更可及。2026年，公司将以'装机一试剂一流水线'的飞轮继续旋转，同时推进海外本地化注册。感谢每一位信任璞兰的股东。

董事长：桂怀璞2026年3月

## 第三节 公司简介和主要财务指标

## 一、公司基本情况

## 公司基本情况

<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">内容</td></tr><tr><td colspan="1" rowspan="1">公司中文全称</td><td colspan="1" rowspan="1">杭州璞兰诊断技术股份有限公司</td></tr><tr><td colspan="1" rowspan="1">证券简称</td><td colspan="1" rowspan="1">璞兰诊断</td></tr><tr><td colspan="1" rowspan="1">证券代码</td><td colspan="1" rowspan="1">301566.SZ</td></tr><tr><td colspan="1" rowspan="1">上市板块</td><td colspan="1" rowspan="1">深圳证券交易所创业板</td></tr><tr><td colspan="1" rowspan="1">注册地/总部</td><td colspan="1" rowspan="1">浙江省杭州市滨江区</td></tr><tr><td colspan="1" rowspan="1">上市时间</td><td colspan="1" rowspan="1">2020年7月</td></tr><tr><td colspan="1" rowspan="1">所处行业</td><td colspan="1" rowspan="1">医疗器械（体外诊断）</td></tr><tr><td colspan="1" rowspan="1">董事长</td><td colspan="1" rowspan="1">桂怀璞</td></tr><tr><td colspan="1" rowspan="1">总经理</td><td colspan="1" rowspan="1">贺照野</td></tr><tr><td colspan="1" rowspan="1">董事会秘书</td><td colspan="1" rowspan="1">满庭芳</td></tr><tr><td colspan="1" rowspan="1">审计机构</td><td colspan="1" rowspan="1">中允会计师事务所(特殊普通合伙)</td></tr><tr><td colspan="1" rowspan="1">员工总数（人）</td><td colspan="1" rowspan="1">4,300</td></tr></table>

## 二、公司历史沿革

公司成立于2009年，总部位于杭州，2020年7月在深圳证券交易所创业板上市，专注于化学发光免疫诊断领域，系国家级专精特新'小巨人'企业。

截至报告期末，公司取得医疗器械注册证214项，其中三类证38项；建有杭州与长沙两大生产基地，发光试剂年产能2.4亿人份。

## 三、主要会计数据和财务指标

## 近三年主要会计数据和财务指标

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>本年比上年增减</td><td rowspan=1 colspan=1>2023年</td></tr><tr><td rowspan=1 colspan=1>营业收入(亿元)</td><td rowspan=1 colspan=1>28.40</td><td rowspan=1 colspan=1>23.80</td><td rowspan=1 colspan=1>+19.3%</td><td rowspan=1 colspan=1>21.40</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润（亿元）</td><td rowspan=1 colspan=1>5.31</td><td rowspan=1 colspan=1>4.78</td><td rowspan=1 colspan=1>+11.1%</td><td rowspan=1 colspan=1>4.35</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的扣除非经常性损益的净利润(亿元)</td><td rowspan=1 colspan=1>4.85</td><td rowspan=1 colspan=1>4.35</td><td rowspan=1 colspan=1>+11.5%</td><td rowspan=1 colspan=1>3.92</td></tr><tr><td rowspan=1 colspan=1>经营活动产生的现金流量净额（亿元）</td><td rowspan=1 colspan=1>7.40</td><td rowspan=1 colspan=1>6.20</td><td rowspan=1 colspan=1>+19.4%</td><td rowspan=1 colspan=1>5.60</td></tr><tr><td rowspan=1 colspan=1>基本每股收益（元/股）</td><td rowspan=1 colspan=1>1.21</td><td rowspan=1 colspan=1>1.09</td><td rowspan=1 colspan=1>+11.1%</td><td rowspan=1 colspan=1>0.99</td></tr><tr><td rowspan=1 colspan=1>加权平均净资产收益率（%）</td><td rowspan=1 colspan=1>14.70</td><td rowspan=1 colspan=1>13.70</td><td rowspan=1 colspan=1>增加1.00个百分点</td><td rowspan=1 colspan=1>13.20</td></tr><tr><td rowspan=1 colspan=1>总资产 (亿元)</td><td rowspan=1 colspan=1>52.40</td><td rowspan=1 colspan=1>48.60</td><td rowspan=1 colspan=1>+7.8%</td><td rowspan=1 colspan=1>一</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净资产（亿元）</td><td rowspan=1 colspan=1>37.20</td><td rowspan=1 colspan=1>35.00</td><td rowspan=1 colspan=1>+6.3%</td><td rowspan=1 colspan=1></td></tr></table>

注：除特别注明外，金额单位均为人民币亿元；净资产收益率口径为加权平均。

## 四、非经常性损益项目及金额

2025年非经常性损益项目明细
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>金额（亿元）</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>计入当期损益的政府补助</td><td rowspan=1 colspan=1>0.18</td><td rowspan=1 colspan=1>高端医疗器械产业化及发光试剂研发专项</td></tr><tr><td rowspan=1 colspan=1>理财收益</td><td rowspan=1 colspan=1>0.10</td><td rowspan=1 colspan=1>闲置募集资金现金管理</td></tr><tr><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1>0.18</td><td rowspan=1 colspan=1>增值税加计抵减及仪器处置收益</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>0.46</td><td rowspan=1 colspan=1>占归母净利润比例 8.7%</td></tr></table>

非经常性损益项目数据来源：公司财务报表附注，并经审计确认。

## 五、分季度主要财务数据

2025年分季度主要财务数据
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>第一季度</td><td rowspan=1 colspan=1>第二季度</td><td rowspan=1 colspan=1>第三季度</td><td rowspan=1 colspan=1>第四季度</td></tr><tr><td rowspan=1 colspan=1>营业收入（亿元）</td><td rowspan=1 colspan=1>6.20</td><td rowspan=1 colspan=1>6.80</td><td rowspan=1 colspan=1>7.40</td><td rowspan=1 colspan=1>8.00</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润(亿元)</td><td rowspan=1 colspan=1>1.12</td><td rowspan=1 colspan=1>1.25</td><td rowspan=1 colspan=1>1.38</td><td rowspan=1 colspan=1>1.56</td></tr></table>

第四节 管理层讨论与分析

## 一、报告期内公司所处行业情况

2025年国内IVD市场规模约1,450亿元，化学发光占比约30%并保持增长。价格端，发光试剂集采以温和降幅落地，国产厂商凭借性价比与快速响应加速替代进口，国产化率从2023年的约35%提升至2025年的约45%。

需求端，医保控费推动检验结果互认与医院降本，具备'仪器+试剂+流水线'整体方案的厂商优势凸显；海外新兴市场对高性价比国产发光系统接受度快速提升。

## 二、报告期内公司从事的主要业务

公司主营业务为化学发光免疫诊断试剂与仪器的研发、生产与销售，配套提供检验流水线与实验室服务，采取'仪器投放、试剂创收'的封闭系统商业模式。

报告期内，公司新一代高速发光仪P-L8000获证上市，肿标与甲状腺套餐试剂注册扩充12项；流水线在三级医院签约42条，期末累计装机突破100条。

## 三、营业收入构成及变动分析

2025年分产品/业务收入构成
<table><tr><td rowspan=1 colspan=1>产品/业务</td><td rowspan=1 colspan=1>收入（亿元）</td><td rowspan=1 colspan=1>收入占比</td><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>收入比上年增减</td></tr><tr><td rowspan=1 colspan=1>化学发光免疫诊断试剂</td><td rowspan=1 colspan=1>21.02</td><td rowspan=1 colspan=1>74.0%</td><td rowspan=1 colspan=1>67.5%</td><td rowspan=1 colspan=1>+22.5%</td></tr><tr><td rowspan=1 colspan=1>诊断仪器</td><td rowspan=1 colspan=1>5.68</td><td rowspan=1 colspan=1>20.0%</td><td rowspan=1 colspan=1>31.5%</td><td rowspan=1 colspan=1>+9.5%</td></tr><tr><td rowspan=1 colspan=1>检验服务及其他</td><td rowspan=1 colspan=1>1.70</td><td rowspan=1 colspan=1>6.0%</td><td rowspan=1 colspan=1>56.0%</td><td rowspan=1 colspan=1>+18.0%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>28.40</td><td rowspan=1 colspan=1>100.0%</td><td rowspan=1 colspan=1>59.6%</td><td rowspan=1 colspan=1>+19.3%</td></tr></table>

化学发光免疫诊断试剂收入21.02亿元，同比增长22.5%，集采放量与装机基数扩大双轮驱动；诊断仪器收入5.68亿元，同比增长9.5%；检验服务及其他收入1.70亿元，同比增长18.0%。

2025年分地区收入构成
<table><tr><td rowspan=1 colspan=1>地区</td><td rowspan=1 colspan=1>收入（亿元）</td><td rowspan=1 colspan=1>收入占比</td></tr><tr><td rowspan=1 colspan=1>境内</td><td rowspan=1 colspan=1>26.44</td><td rowspan=1 colspan=1>93.1%</td></tr><tr><td rowspan=1 colspan=1>境外</td><td rowspan=1 colspan=1>1.96</td><td rowspan=1 colspan=1>6.9%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>28.40</td><td rowspan=1 colspan=1>100.0%</td></tr></table>

注：前五名客户合计销售金额占年度销售总额的18.6%。

## 四、营业成本构成

营业成本构成（占营业成本比例）
<table><tr><td rowspan=1 colspan=1>成本项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=2 colspan=1>变动说明核心原料自研比例升至41%</td></tr><tr><td rowspan=1 colspan=1>试剂原料（抗原/抗体/磁微粒)</td><td rowspan=1 colspan=1>52.3%</td><td rowspan=1 colspan=1>53.6%</td></tr><tr><td rowspan=1 colspan=1>耗材及包材</td><td rowspan=1 colspan=1>22.6%</td><td rowspan=1 colspan=1>22.2%</td><td rowspan=1 colspan=1>国产替代采购</td></tr><tr><td rowspan=1 colspan=1>人工及制造费用</td><td rowspan=1 colspan=1>25.1%</td><td rowspan=1 colspan=1>24.2%</td><td rowspan=1 colspan=1>长沙基地产能爬坡摊薄</td></tr></table>

## 五、期间费用与研发投入

## 期间费用变动

<table><tr><td rowspan=1 colspan=1>费用项目</td><td rowspan=1 colspan=1>2025年（亿元）</td><td rowspan=1 colspan=1>2024年（亿元）</td><td rowspan=1 colspan=1>同比</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>6.20</td><td rowspan=1 colspan=1>5.35</td><td rowspan=1 colspan=1>+15.9%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>2.35</td><td rowspan=1 colspan=1>2.15</td><td rowspan=1 colspan=1>+9.3%</td></tr><tr><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>2.40</td><td rowspan=1 colspan=1>2.05</td><td rowspan=1 colspan=1>+17.1%</td></tr><tr><td rowspan=1 colspan=1>财务费用</td><td rowspan=1 colspan=1>-0.28</td><td rowspan=1 colspan=1>-0.22</td><td rowspan=1 colspan=1>+27.3%</td></tr></table>

研发投入方面，公司2025年研发投入合计2.60亿元，占营业收入比例9.2%，其中费用化研发费用2.40亿元、资本化研发投入0.20亿元；研发人员860人，占员工总数比例20.0%。

## 六、现金流量情况

现金流量主要项目
<table><tr><td rowspan=2 colspan=1>项目经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>2025年(亿元）</td><td rowspan=1 colspan=1>2024年(亿元）</td></tr><tr><td rowspan=1 colspan=1>7.40</td><td rowspan=1 colspan=1>6.20</td></tr><tr><td rowspan=1 colspan=1>投资活动产生的现金流量净额</td><td rowspan=1 colspan=1>-3.10</td><td rowspan=1 colspan=1>-2.60</td></tr><tr><td rowspan=1 colspan=1>筹资活动产生的现金流量净额</td><td rowspan=1 colspan=1>0.40</td><td rowspan=1 colspan=1>0.80</td></tr></table>

报告期内经营活动现金流量净额7.40亿元，同比增长19.4%，高于当期净利润；投资活动净流出3.10亿元，主要为产能建设与理财投入；筹资活动净流入0.40亿元。

## 七、资产及负债项目重大变动

资产、负债项目重大变动
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末(亿元)</td><td rowspan=1 colspan=1>期初(亿元)</td><td rowspan=1 colspan=1>变动比例</td><td rowspan=1 colspan=1>变动原因</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>9.80</td><td rowspan=1 colspan=1>9.20</td><td rowspan=1 colspan=1>+6.5%</td><td rowspan=1 colspan=1>经营积累</td></tr><tr><td rowspan=1 colspan=1>应收账款及合同资产</td><td rowspan=1 colspan=1>8.40</td><td rowspan=1 colspan=1>7.60</td><td rowspan=1 colspan=1>+10.5%</td><td rowspan=1 colspan=1>集采结算方式下回款稳定</td></tr><tr><td rowspan=1 colspan=1>固定资产及在建工程</td><td rowspan=1 colspan=1>14.60</td><td rowspan=1 colspan=1>13.20</td><td rowspan=1 colspan=1>+10.6%</td><td rowspan=1 colspan=1>长沙试剂基地二期投产</td></tr></table>

## 八、公司未来发展的展望

2026年经营目标：营业收入34亿元左右，同比增长约20%；发光仪器新增装机1,200台，流水线签约60条；境外收入实现翻番，重点突破东南亚与中东本地化注册。

研发方面，公司将推进全自动样本前处理系统注册，并对自身免疫与过敏原检测两大新菜单立项，持续丰富试剂套餐。

## 九、风险因素

公司在本报告期及未来经营中可能面临以下主要风险，敬请投资者关注：

集采降价风险：若后续试剂集采范围扩大或降幅超预期，公司将面临以量补价的压力。

封闭系统风险：仪器投放模式的资产周转与试剂上量存在时滞，投放强度影响短期利润。

原料依赖风险：部分高亲和性抗体、磁性微球等核心原料若自研进度不及预期，仍需外购。

竞争风险：发光赛道国产头部集中，价格与渠道竞争激烈。

应收账款风险：医院客户回款周期受医保资金拨付节奏影响。

## 第五节 董事会报告

报告期内，公司共召开董事会会议9次、监事会会议5次、股东大会2次。公司董事会严格执行股东大会决议，勤勉尽责开展各项工作，2025年6月完成了上一年度利润分配方案的实施。

公司2025年度利润分配预案为：以实施权益分派股权登记日登记的总股本为基数，每10股派发现金红利3.50元(含税)，合计派发现金红利1.54亿元（含税)，占2025年度归属于上市公司股东净利润的29.00%。

公司2025年度财务报告审计机构为中允会计师事务所(特殊普通合伙），报告期内公司不存在改聘、解聘会计师事务所的情形。公司已就2026年度财务报告审计服务续聘中允会计师事务所（特殊普通合伙）并提请股东大会审议，审计收费180万元。

## 第六节 公司治理

报告期内，公司按照《公司法》《证券法》《上市公司治理准则》及公司章程的要求规范运作。公司董事会由9名董事组成，其中独立董事3名，占比不低于三分之一；监事会由3名监事组成，其中职工代表监事1名。董事会下设战略委员会、审计委员会、提名委员会、薪酬与考核委员会四个专门委员会，报告期内共召开专门委员会会议6次。

投资者关系方面，报告期内公司通过业绩说明会、投资者调研接待、互动平台答复等方式与投资者保持沟通，共接待机构投资者调研28批次，举办业绩说明会3次，回复互动平台提问120条。

内部控制方面，公司已建立覆盖全部业务流程的内部控制体系，报告期内未发现财务报告内部控制重大缺陷或重要缺陷。

## 第七节环境、社会责任和其他公司治理

## 一、环境保护信息

## 环境信息主要指标

<table><tr><td rowspan=1 colspan=1>指标</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>同比变动</td></tr><tr><td rowspan=1 colspan=1>危险废物规范化处置率</td><td rowspan=1 colspan=1>100%</td><td rowspan=1 colspan=1>持平</td></tr><tr><td rowspan=1 colspan=1>综合能耗（吨标准煤）</td><td rowspan=1 colspan=1>9,800</td><td rowspan=1 colspan=1>+4.2%</td></tr><tr><td rowspan=1 colspan=1>温室气体排放范围一+二（吨CO2e)</td><td rowspan=1 colspan=1>23,600</td><td rowspan=1 colspan=1>+3.8%</td></tr><tr><td rowspan=1 colspan=1>环保投入（万元）</td><td rowspan=1 colspan=1>310</td><td rowspan=1 colspan=1>+10.0%</td></tr></table>

公司主导发起西部县域检验科帮扶计划，累计向160家县级医院捐赠设备与培训支持；报告期内无环保处罚记录。

## 二、社会责任

截至报告期末，公司员工总数4,300人，其中研发人员860人。报告期内公司持续完善职业发展通道与培训体系，人均培训时长24小时；全年对外捐赠及公益投入260万元，重点投向教育帮扶与乡村振兴领域。

## 三、公司治理专项情况

报告期内，公司控股股东、实际控制人不存在违规占用公司资金的情况，公司及控股子公司未发生违规对外担保。公司已披露ESG相关专项报告，详情见公司可持续发展报告。

## 第八节 重要事项

集采中标情况：报告期内公司在安徽牵头联盟发光试剂集采中肿标、甲状腺、心肌三大套餐全部中标，价格降幅温和。

重大诉讼、仲裁事项：报告期内公司不存在重大诉讼、仲裁事项。

对外担保：报告期内公司不存在对外担保事项。

关联交易：报告期内公司与关联方发生的日常关联交易合计金额为120万元，程序合规。

股权激励：报告期内公司实施2025年限制性股票激励计划，向95名核心人员授予210万股，考核目标为2026-2027年试剂收入复合增长率不低于20%。

## 第九节 股份变动及股东情况

股份结构(万股)
<table><tr><td rowspan=1 colspan=1>股份类别</td><td rowspan=1 colspan=1>数量(万股)</td><td rowspan=1 colspan=1>占总股本比例</td></tr><tr><td rowspan=1 colspan=1>无限售条件流通股</td><td rowspan=1 colspan=1>37,400.0</td><td rowspan=1 colspan=1>85.00%</td></tr><tr><td rowspan=1 colspan=1>限售股</td><td rowspan=1 colspan=1>6,600.0</td><td rowspan=1 colspan=1>15.00%</td></tr><tr><td rowspan=1 colspan=1>股份总数</td><td rowspan=1 colspan=1>44,000.0</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

## 前十大股东持股情况

截至2025年12月31日前十大股东
<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>股东名称</td><td rowspan=1 colspan=1>持股比例</td><td rowspan=1 colspan=1>股东性质</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>璞兰控股集团有限公司</td><td rowspan=1 colspan=1>25.80%</td><td rowspan=1 colspan=1>境内非国有法人</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>浙江省产业基金有限公司</td><td rowspan=1 colspan=1>7.40%</td><td rowspan=1 colspan=1>国有法人</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>香港中央结算有限公司</td><td rowspan=1 colspan=1>5.20%</td><td rowspan=1 colspan=1>境外法人</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>高瓴医疗健康产业基金</td><td rowspan=1 colspan=1>4.30%</td><td rowspan=1 colspan=1>境内非国有法人</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>全国社保基金——四组合</td><td rowspan=1 colspan=1>3.40%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>基本养老保险基金八零六组合</td><td rowspan=1 colspan=1>2.80%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>招商国证生物医药指数基金</td><td rowspan=1 colspan=1>2.30%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>璞兰员工持股计划</td><td rowspan=1 colspan=1>1.90%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>中欧医疗健康混合型证券投资基金</td><td rowspan=1 colspan=1>1.60%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>易方达创业板ETF</td><td rowspan=1 colspan=1>1.20%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>前十大股东合计</td><td rowspan=1 colspan=1>55.90%</td><td rowspan=1 colspan=1></td></tr></table>

公司控股股东为璞兰控股集团有限公司，实际控制人为桂怀璞。控股股东所持股份报告期内不存在质押、冻结情形。

## 第十节 财务报告

## 一、审计意见

公司2025年度财务报表业经中允会计师事务所(特殊普通合伙)审计，并于2026年3月出具了标准无保留意见(中允审字[2026]第0234号）。审计机构认为：公司财务报表在所有重大方面按照企业会计准则的规

定编制，公允反映了公司2025年12月31日的合并及公司财务状况以及2025年度的合并及公司经营成果和现金流量。

## 二、合并资产负债表主要项目(摘要)

## 资产负债表主要项目

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末（亿元）</td><td rowspan=1 colspan=1>期初（亿元)</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>9.80</td><td rowspan=1 colspan=1>9.20</td></tr><tr><td rowspan=1 colspan=1>应收账款及合同资产</td><td rowspan=1 colspan=1>8.40</td><td rowspan=1 colspan=1>7.60</td></tr><tr><td rowspan=1 colspan=1>存货</td><td rowspan=1 colspan=1>4.20</td><td rowspan=1 colspan=1>3.80</td></tr><tr><td rowspan=1 colspan=1>固定资产及在建工程</td><td rowspan=1 colspan=1>14.60</td><td rowspan=1 colspan=1>13.20</td></tr><tr><td rowspan=1 colspan=1>其他资产</td><td rowspan=1 colspan=1>15.40</td><td rowspan=1 colspan=1>14.80</td></tr><tr><td rowspan=1 colspan=1>资产总计</td><td rowspan=1 colspan=1>52.40</td><td rowspan=1 colspan=1>48.60</td></tr><tr><td rowspan=1 colspan=1>应付账款及应付票据</td><td rowspan=1 colspan=1>5.20</td><td rowspan=1 colspan=1>4.60</td></tr><tr><td rowspan=1 colspan=1>合同负债</td><td rowspan=1 colspan=1>2.80</td><td rowspan=1 colspan=1>2.20</td></tr><tr><td rowspan=1 colspan=1>借款及其他负债</td><td rowspan=1 colspan=1>7.20</td><td rowspan=1 colspan=1>6.80</td></tr><tr><td rowspan=1 colspan=1>负债合计</td><td rowspan=1 colspan=1>15.20</td><td rowspan=1 colspan=1>13.60</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东权益合计</td><td rowspan=1 colspan=1>37.20</td><td rowspan=1 colspan=1>35.00</td></tr></table>

注：上述为合并口径主要项目摘要，完整资产负债表及附注以公司指定信息披露媒体披露的版本为准。

## 三、合并利润表主要项目（摘要)

利润表主要项目
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年(亿元）</td><td rowspan=1 colspan=1>2024年（亿元）</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>28.40</td><td rowspan=1 colspan=1>23.80</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>11.47</td><td rowspan=1 colspan=1>9.78</td></tr><tr><td rowspan=1 colspan=1>期间费用合计</td><td rowspan=1 colspan=1>10.67</td><td rowspan=1 colspan=1>9.33</td></tr><tr><td rowspan=1 colspan=1>研发费用（含于期间费用）</td><td rowspan=1 colspan=1>2.40</td><td rowspan=1 colspan=1>2.05</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的净利润</td><td rowspan=1 colspan=1>5.31</td><td rowspan=1 colspan=1>4.78</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的扣除非经常性损益的净利润</td><td rowspan=1 colspan=1>4.85</td><td rowspan=1 colspan=1>4.35</td></tr></table>

## 四、合并现金流量表主要项目(摘要)

现金流量表主要项目
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年(亿元)</td><td rowspan=1 colspan=1>2024年（亿元）</td></tr><tr><td rowspan=1 colspan=1>经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>7.40</td><td rowspan=1 colspan=1>6.20</td></tr><tr><td rowspan=1 colspan=1>投资活动产生的现金流量净额</td><td rowspan=1 colspan=1>-3.10</td><td rowspan=1 colspan=1>-2.60</td></tr><tr><td rowspan=1 colspan=1>筹资活动产生的现金流量净额</td><td rowspan=1 colspan=1>0.40</td><td rowspan=1 colspan=1>0.80</td></tr></table>

公司执行财政部颁布的企业会计准则及相关规定，主要会计政策与上一年度保持一致，报告期内无重大会计估计变更。

## 备查文件目录

载有公司法定代表人、主管会计工作负责人、会计机构负责人签名并盖章的财务报表。

·载有会计师事务所盖章、注册会计师签名并盖章的2025年度审计报告原件。

·报告期内公开披露过的所有公司文件的正本及公告原稿。

公司2025年年度股东大会会议资料及决议。

(本报告为模拟数据，仅供研究测试使用，不构成任何投资建议)