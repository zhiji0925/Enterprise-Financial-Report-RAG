# 黄山翠微文旅股份有限公司

2025 年年度报告

(股票简称：翠微文旅股票代码：600987.SH)(上海证券交易所主板)

披露日期：2026年3月31日

公司统一社会信用代码：91341000MA2T5R8HKE

## 重要提示

一、公司董事会、监事会及董事、监事、高级管理人员保证年度报告内容的真实、准确、完整，不存在虚假记载、误导性陈述或重大遗漏，并承担个别和连带的法律责任。

二、公司2025年度利润分配预案为：以实施权益分派股权登记日登记的总股本为基数，每10股派发现金红利3.50元(含税)，合计派发现金红利1.12亿元（含税)，占2025年度归属于上市公司股东净利润的37.09%。该预案尚需提交公司2025年年度股东大会审议。

三、公司全体董事出席了审议本次年度报告的董事会会议，会议以9票同意、0票反对、0票弃权审议通过了本报告。

四、公司2025年度财务报告已经中衡会计师事务所（特殊普通合伙）审计，并出具了标准无保留意见审计报告（中衡审字[2026]第0579号）。

五、本报告所载未来计划、经营目标等前瞻性陈述不构成公司对投资者的实质性承诺，投资者应当对此保持足够的风险认识。

六、报告期内，不存在控股股东及其关联方非经营性占用公司资金的情况。

七、报告期内，公司不存在违反规定程序对外提供担保的情况。

八、公司负责人章秋帆、主管会计工作负责人山秉烛及会计机构负责人（财务部部长）保证本报告中财务报告的真实、准确、完整。

九、敬请投资者认真阅读本报告第四节'管理层讨论与分析'中'风险因素'部分的内容，充分关注公司经营中可能面临的相关风险。

重要提示  
第一节释义  
第二节 致股东的信  
第三节公司简介和主要财务指标  
第四节 管理层讨论与分析  
第五节 董事会报告  
第六节公司治理  
第七节环境、社会责任和其他公司治理  
第八节 重要事项  
第九节股份变动及股东情况  
第十节财务报告  
备查文件目录

## 目录

## 第一节释义

## 释义表

<table><tr><td rowspan=1 colspan=1>术语/简称</td><td rowspan=1 colspan=1>释义</td></tr><tr><td rowspan=1 colspan=1>公司、翠微文旅</td><td rowspan=1 colspan=1>指黄山翠微文旅股份有限公司</td></tr><tr><td rowspan=1 colspan=1>二消</td><td rowspan=1 colspan=1>指游客在门票之外的索道、演艺、文创等二次消费</td></tr><tr><td rowspan=1 colspan=1>夜游</td><td rowspan=1 colspan=1>指利用夜间时段开放的游览与演艺产品</td></tr><tr><td rowspan=1 colspan=1>索道客运</td><td rowspan=1 colspan=1>指以客运索道输送游客的收费业务</td></tr><tr><td rowspan=1 colspan=1>入境游客</td><td rowspan=1 colspan=1>指持境外证件入境游览的游客</td></tr><tr><td rowspan=1 colspan=1>过夜率</td><td rowspan=1 colspan=1>指进入景区游客中留宿至少一晚的比例</td></tr><tr><td rowspan=1 colspan=1>门票价格听证</td><td rowspan=1 colspan=1>指国有景区调价须履行的听证程序</td></tr><tr><td rowspan=1 colspan=1>黄金周</td><td rowspan=1 colspan=1>指国家法定长假旅游高峰期</td></tr></table>

## 第二节 致股东的信

2025年，山还是那座山，上山的人却更多了。翠微文旅实现营业收入12.80亿元，同比增长14.3%；归属于上市公司股东的净利润3.02亿元，同比增长12.7%；全年接待游客568万人次，其中入境游客同比增长68%，夜游产品贡献二次消费收入占比达29%。

这一年，公司把'看山'升级为'住山'：山顶酒店完成第四轮改造，过夜率提升至18.5%；翠微夜画'演艺项目第二期开演，暑期连续三个月上座率超90%；240小时过境免签政策红利下，公司与12家海外旅行商建立直客合作。

名山是老天爷留给我们的资产，服务是我们写给游客的信。2026年，公司将持续把流量转化为留量，推进索道设备更新与数字化票务，让每一位游客的登山体验更从容。感谢股东与社会各界的支持。

董事长：章秋帆 2026年3月

## 第三节 公司简介和主要财务指标

## 一、公司基本情况

公司基本情况
<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">内容</td></tr><tr><td colspan="1" rowspan="1">公司中文全称</td><td colspan="1" rowspan="1">黄山翠微文旅股份有限公司</td></tr><tr><td colspan="1" rowspan="1">证券简称</td><td colspan="1" rowspan="1">翠微文旅</td></tr><tr><td colspan="1" rowspan="1">证券代码</td><td colspan="1" rowspan="1">600987.SH</td></tr><tr><td colspan="1" rowspan="1">上市板块</td><td colspan="1" rowspan="1">上海证券交易所主板</td></tr><tr><td colspan="1" rowspan="1">注册地/总部</td><td colspan="1" rowspan="1">安徽省黄山市黄山区</td></tr><tr><td colspan="1" rowspan="1">上市时间</td><td colspan="1" rowspan="1">1997年5月</td></tr><tr><td colspan="1" rowspan="1">所处行业</td><td colspan="1" rowspan="1">景区文旅</td></tr><tr><td colspan="1" rowspan="1">董事长</td><td colspan="1" rowspan="1">章秋帆</td></tr><tr><td colspan="1" rowspan="1">总经理</td><td colspan="1" rowspan="1">邾晓岚</td></tr><tr><td colspan="1" rowspan="1">董事会秘书</td><td colspan="1" rowspan="1">山秉烛</td></tr><tr><td colspan="1" rowspan="1">审计机构</td><td colspan="1" rowspan="1">中衡会计师事务所(特殊普通合伙)</td></tr><tr><td colspan="1" rowspan="1">员工总数（人）</td><td colspan="1" rowspan="1">4,200</td></tr></table>

## 二、公司历史沿革

公司前身为国营翠微山林场旅游经营单位，1997年5月在上海证券交易所主板上市，是自然山岳型景区的代表性企业，经营翠微峰景区的索道、门票、酒店及文旅综合业务。

截至报告期末，公司运营客运索道3条、山顶及山麓酒店6家(客房1,120间)、夜游演艺1台，并管理景区内全部游览步道与配套服务设施。

## 三、主要会计数据和财务指标

近三年主要会计数据和财务指标
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>本年比上年增减</td><td rowspan=1 colspan=1>2023年</td></tr><tr><td rowspan=1 colspan=1>营业收入(亿元)</td><td rowspan=1 colspan=1>12.80</td><td rowspan=1 colspan=1>11.20</td><td rowspan=1 colspan=1>+14.3%</td><td rowspan=1 colspan=1>9.80</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润（亿元）</td><td rowspan=1 colspan=1>3.02</td><td rowspan=1 colspan=1>2.68</td><td rowspan=1 colspan=1>+12.7%</td><td rowspan=1 colspan=1>2.35</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的扣除非经常性损益的净利润 (亿元)</td><td rowspan=1 colspan=1>2.86</td><td rowspan=1 colspan=1>2.54</td><td rowspan=1 colspan=1>+12.6%</td><td rowspan=1 colspan=1>2.20</td></tr><tr><td rowspan=1 colspan=1>经营活动产生的现金流量净额（亿元）</td><td rowspan=1 colspan=1>4.50</td><td rowspan=1 colspan=1>4.00</td><td rowspan=1 colspan=1>+12.5%</td><td rowspan=1 colspan=1>3.60</td></tr><tr><td rowspan=1 colspan=1>基本每股收益（元/股）</td><td rowspan=1 colspan=1>0.94</td><td rowspan=1 colspan=1>0.84</td><td rowspan=1 colspan=1>+12.7%</td><td rowspan=1 colspan=1>0.73</td></tr><tr><td rowspan=1 colspan=1>加权平均净资产收益率（%)</td><td rowspan=1 colspan=1>10.50</td><td rowspan=1 colspan=1>9.50</td><td rowspan=1 colspan=1>增加1.00个百分点</td><td rowspan=1 colspan=1>8.70</td></tr><tr><td rowspan=1 colspan=1>总资产 (亿元)</td><td rowspan=1 colspan=1>40.60</td><td rowspan=1 colspan=1>38.80</td><td rowspan=1 colspan=1>+4.6%</td><td rowspan=1 colspan=1>一</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净资产（亿元)</td><td rowspan=1 colspan=1>29.30</td><td rowspan=1 colspan=1>28.20</td><td rowspan=1 colspan=1>+3.9%</td><td rowspan=1 colspan=1>一</td></tr></table>

注：除特别注明外，金额单位均为人民币亿元；净资产收益率口径为加权平均。

## 四、非经常性损益项目及金额

2025年非经常性损益项目明细
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>金额（亿元）</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>计入当期损益的政府补助</td><td rowspan=1 colspan=1>0.09</td><td rowspan=1 colspan=1>文旅产业扶持与景区基础设施专项</td></tr><tr><td rowspan=1 colspan=1>理财收益</td><td rowspan=1 colspan=1>0.04</td><td rowspan=1 colspan=1>闲置自有资金现金管理</td></tr><tr><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1>0.03</td><td rowspan=1 colspan=1>增值税加计抵减等</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>0.16</td><td rowspan=1 colspan=1>占归母净利润比例 5.3%</td></tr></table>

非经常性损益项目数据来源：公司财务报表附注，并经审计确认。

## 五、分季度主要财务数据

2025年分季度主要财务数据
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>第一季度</td><td rowspan=1 colspan=1>第二季度</td><td rowspan=1 colspan=1>第三季度</td><td rowspan=1 colspan=1>第四季度</td></tr><tr><td rowspan=1 colspan=1>营业收入（亿元）</td><td rowspan=1 colspan=1>2.10</td><td rowspan=1 colspan=1>3.60</td><td rowspan=1 colspan=1>4.30</td><td rowspan=1 colspan=1>2.80</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润(亿元)</td><td rowspan=1 colspan=1>0.48</td><td rowspan=1 colspan=1>0.86</td><td rowspan=1 colspan=1>1.10</td><td rowspan=1 colspan=1>0.58</td></tr></table>

## 第四节 管理层讨论与分析

## 一、报告期内公司所处行业情况

2025年国内旅游人次与旅游收入均创历史新高，同比增长分别约15%与17%；入境游在免签政策扩围驱动下加速修复，全年入境外国人同比增长约60%。政策端，《提振消费专项行动方案》将文旅列为重点领域。

供给端，山岳型景区竞争转向'深度体验'：夜游演艺、山顶住宿与文创二消成为核心变量；门票价格政策保持稳定背景下，二消占比成为衡量景区运营能力的首要指标。

## 二、报告期内公司从事的主要业务

公司主营业务为翠微峰景区的索道客运、门票销售、酒店度假与文旅演艺，并以限量预约、错峰引导的方式管理客流。

报告期内，云谷索道完成主机更新改造，运力提升20%；翠微夜画'二期投运；山顶狮林精舍改造后平均房价提升23%，旺季入住率达88%。

## 三、营业收入构成及变动分析

2025年分产品/业务收入构成
<table><tr><td rowspan=1 colspan=1>产品/业务</td><td rowspan=1 colspan=1>收入（亿元）</td><td rowspan=1 colspan=1>收入占比</td><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>收入比上年增减</td></tr><tr><td rowspan=1 colspan=1>索道及客运</td><td rowspan=1 colspan=1>5.63</td><td rowspan=1 colspan=1>44.0%</td><td rowspan=1 colspan=1>70.0%</td><td rowspan=1 colspan=1>+10.9%</td></tr><tr><td rowspan=1 colspan=1>景区门票及二消</td><td rowspan=1 colspan=1>4.10</td><td rowspan=1 colspan=1>32.0%</td><td rowspan=1 colspan=1>55.0%</td><td rowspan=1 colspan=1>+12.6%</td></tr><tr><td rowspan=1 colspan=1>酒店及度假</td><td rowspan=1 colspan=1>3.07</td><td rowspan=1 colspan=1>24.0%</td><td rowspan=1 colspan=1>42.0%</td><td rowspan=1 colspan=1>+14.6%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>12.80</td><td rowspan=1 colspan=1>100.0%</td><td rowspan=1 colspan=1>58.2%</td><td rowspan=1 colspan=1>+14.3%</td></tr></table>

索道及客运收入5.63亿元，同比增长10.9%，客流增长与运力扩容共振；景区门票及二消收入4.10亿元，同比增长12.6%，夜游演艺与文创放量；酒店及度假收入3.07亿元，同比增长14.6%，改造后的山顶酒店提价效应显现。

2025年分地区收入构成
<table><tr><td rowspan=1 colspan=1>地区</td><td rowspan=1 colspan=1>收入（亿元）</td><td rowspan=1 colspan=1>收入占比</td></tr><tr><td rowspan=1 colspan=1>境内</td><td rowspan=1 colspan=1>12.16</td><td rowspan=1 colspan=1>95.0%</td></tr><tr><td rowspan=1 colspan=1>境外</td><td rowspan=1 colspan=1>0.64</td><td rowspan=1 colspan=1>5.0%</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>12.80</td><td rowspan=1 colspan=1>100.0%</td></tr></table>

注：前五名客户合计销售金额占年度销售总额的4.1%。

## 四、营业成本构成

营业成本构成（占营业成本比例）
<table><tr><td rowspan=1 colspan=1>成本项目</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>变动说明</td></tr><tr><td rowspan=1 colspan=1>人工及运营费用</td><td rowspan=1 colspan=1>52.4%</td><td rowspan=1 colspan=1>53.8%</td><td rowspan=1 colspan=1>夜游项目新增演职人员</td></tr><tr><td rowspan=1 colspan=1>维修与安全保障</td><td rowspan=1 colspan=1>24.6%</td><td rowspan=1 colspan=1>23.1%</td><td rowspan=1 colspan=1>索道设备更新改造</td></tr><tr><td rowspan=1 colspan=1>物料及能耗</td><td rowspan=1 colspan=1>23.0%</td><td rowspan=1 colspan=1>23.1%</td><td rowspan=1 colspan=1>酒店客房改造后能耗优化</td></tr></table>

## 五、期间费用与研发投入

## 期间费用变动

<table><tr><td rowspan=1 colspan=1>费用项目</td><td rowspan=1 colspan=1>2025年（亿元）</td><td rowspan=1 colspan=1>2024年（亿元）</td><td rowspan=1 colspan=1>同比</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>0.62</td><td rowspan=1 colspan=1>0.55</td><td rowspan=1 colspan=1>+12.7%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>1.85</td><td rowspan=1 colspan=1>1.72</td><td rowspan=1 colspan=1>+7.6%</td></tr><tr><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>0.35</td><td rowspan=1 colspan=1>0.30</td><td rowspan=1 colspan=1>+16.7%</td></tr><tr><td rowspan=1 colspan=1>财务费用</td><td rowspan=1 colspan=1>0.02</td><td rowspan=1 colspan=1>0.03</td><td rowspan=1 colspan=1>-33.3%</td></tr></table>

研发投入方面，公司2025年研发投入合计0.35亿元，占营业收入比例2.7%，其中费用化研发费用0.35亿元、资本化研发投入0.00亿元；研发人员180人，占员工总数比例4.3%。

## 六、现金流量情况

现金流量主要项目
<table><tr><td rowspan=2 colspan=1>项目经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>2025年(亿元）</td><td rowspan=1 colspan=1>2024年(亿元）</td></tr><tr><td rowspan=1 colspan=1>4.50</td><td rowspan=1 colspan=1>4.00</td></tr><tr><td rowspan=1 colspan=1>投资活动产生的现金流量净额</td><td rowspan=1 colspan=1>-1.60</td><td rowspan=1 colspan=1>-1.40</td></tr><tr><td rowspan=1 colspan=1>筹资活动产生的现金流量净额</td><td rowspan=1 colspan=1>0.40</td><td rowspan=1 colspan=1>0.50</td></tr></table>

报告期内经营活动现金流量净额4.50亿元，同比增长12.5%，与净利润保持高质量匹配；投资活动净流出1.60亿元，为索道更新与酒店改造；筹资活动净流入0.40亿元。

## 七、资产及负债项目重大变动

资产、负债项目重大变动
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末（亿元）</td><td rowspan=1 colspan=1>期初(亿元)</td><td rowspan=1 colspan=1>变动比例</td><td rowspan=1 colspan=1>变动原因</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>8.20</td><td rowspan=1 colspan=1>7.60</td><td rowspan=1 colspan=1>+7.9%</td><td rowspan=1 colspan=1>经营积累</td></tr><tr><td rowspan=1 colspan=1>固定资产及在建工程</td><td rowspan=1 colspan=1>24.60</td><td rowspan=1 colspan=1>23.80</td><td rowspan=1 colspan=1>+3.4%</td><td rowspan=1 colspan=1>索道更新与酒店改造</td></tr><tr><td rowspan=1 colspan=1>合同负债</td><td rowspan=1 colspan=1>3.80</td><td rowspan=1 colspan=1>3.40</td><td rowspan=1 colspan=1>+11.8%</td><td rowspan=1 colspan=1>预售门票、房券与年卡</td></tr></table>

## 八、公司未来发展的展望

2026年经营目标：营业收入14.2亿元左右，同比增长约11%；游客量600万人次，过夜率提升至20%，二消收入占比突破32%。

项目方面，公司将启动西海大峡谷观光缆车前期工作，完成数字化票务与分时预约系统升级，并新增两条入境游客专属产品线。

## 九、风险因素

公司在本报告期及未来经营中可能面临以下主要风险，敬请投资者关注：

客流波动风险：极端天气、公共卫生事件等不可抗力对客流影响直接。

门票政策风险：国有景区门票价格受政府指导，调价空间有限。

安全运营风险：索道与山地游览安全责任重大，容错率低。

项目投资风险：酒店与演艺改造投入大，回报周期受客流波动影响。

竞争风险：周边及全国同类山岳景区分流，产品同质化压力上升。

## 第五节 董事会报告

报告期内，公司共召开董事会会议8次、监事会会议4次、股东大会2次。公司董事会严格执行股东大会决议，勤勉尽责开展各项工作，2025年6月完成了上一年度利润分配方案的实施。

公司2025年度利润分配预案为：以实施权益分派股权登记日登记的总股本为基数，每10股派发现金红利3.50元(含税)，合计派发现金红利1.12亿元（含税)，占2025年度归属于上市公司股东净利润的37.09%。

公司2025年度财务报告审计机构为中衡会计师事务所(特殊普通合伙），报告期内公司不存在改聘、解聘会计师事务所的情形。公司已就2026年度财务报告审计服务续聘中衡会计师事务所（特殊普通合伙）并提请股东大会审议，审计收费180万元。

## 第六节 公司治理

报告期内，公司按照《公司法》《证券法》《上市公司治理准则》及公司章程的要求规范运作。公司董事会由9名董事组成，其中独立董事3名，占比不低于三分之一；监事会由3名监事组成，其中职工代表监事1名。董事会下设战略委员会、审计委员会、提名委员会、薪酬与考核委员会四个专门委员会，报告期内共召开专门委员会会议6次。

投资者关系方面，报告期内公司通过业绩说明会、投资者调研接待、互动平台答复等方式与投资者保持沟通，共接待机构投资者调研28批次，举办业绩说明会3次，回复互动平台提问120条。

内部控制方面，公司已建立覆盖全部业务流程的内部控制体系，报告期内未发现财务报告内部控制重大缺陷或重要缺陷。

## 第七节环境、社会责任和其他公司治理

## 一、环境保护信息

## 环境信息主要指标

<table><tr><td rowspan=1 colspan=1>指标</td><td rowspan=1 colspan=1>2025年</td><td rowspan=1 colspan=1>同比变动</td></tr><tr><td rowspan=1 colspan=1>景区垃圾资源化处理率</td><td rowspan=1 colspan=1>92.0%</td><td rowspan=1 colspan=1>提高4.0个百分点</td></tr><tr><td rowspan=1 colspan=1>综合能耗(吨标准煤)</td><td rowspan=1 colspan=1>8,900</td><td rowspan=1 colspan=1>+3.8%</td></tr><tr><td rowspan=1 colspan=1>水资源消耗（万立方米）</td><td rowspan=1 colspan=1>56.4</td><td rowspan=1 colspan=1>+5.2%</td></tr><tr><td rowspan=1 colspan=1>环保投入（万元）</td><td rowspan=1 colspan=1>620</td><td rowspan=1 colspan=1>+12.0%</td></tr></table>

公司持续实施'垃圾下山'工程与古树名木保护专项，报告期内景区空气与水体质量均达国家一类标准。

## 二、社会责任

截至报告期末，公司员工总数4,200人，其中研发人员180人。报告期内公司持续完善职业发展通道与培训体系，人均培训时长24小时；全年对外捐赠及公益投入260万元，重点投向教育帮扶与乡村振兴领域。

## 三、公司治理专项情况

报告期内，公司控股股东、实际控制人不存在违规占用公司资金的情况，公司及控股子公司未发生违规对外担保。公司已披露ESG相关专项报告，详情见公司可持续发展报告。

## 第八节 重要事项

重大投资：报告期内公司完成西海饭店资产收购，交易金额1.2亿元，扩大山顶优质住宿供给。

重大诉讼、仲裁事项：报告期内公司不存在重大诉讼、仲裁事项。

对外担保：报告期内公司不存在对外担保事项。

关联交易：报告期内公司与关联方发生的日常关联交易合计金额为1,350万元，主要为综合服务与采购，定价公允。

政府补助：报告期内计入递延收益与当期损益的政府补助合计1,500万元，为景区基础设施与文旅产业专项。

## 第九节股份变动及股东情况

## 股份结构(万股)

<table><tr><td rowspan=1 colspan=1>股份类别</td><td rowspan=1 colspan=1>数量(万股)</td><td rowspan=1 colspan=1>占总股本比例</td></tr><tr><td rowspan=1 colspan=1>无限售条件流通股</td><td rowspan=1 colspan=1>31,360.0</td><td rowspan=1 colspan=1>98.00%</td></tr><tr><td rowspan=1 colspan=1>限售股</td><td rowspan=1 colspan=1>640.0</td><td rowspan=1 colspan=1>2.00%</td></tr><tr><td rowspan=1 colspan=1>股份总数</td><td rowspan=1 colspan=1>32,000.0</td><td rowspan=1 colspan=1>100.00%</td></tr></table>

## 前十大股东持股情况

截至2025年12月31日前十大股东
<table><tr><td rowspan=1 colspan=1>序号</td><td rowspan=1 colspan=1>股东名称</td><td rowspan=1 colspan=1>持股比例</td><td rowspan=1 colspan=1>股东性质</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>翠微文旅集团有限公司</td><td rowspan=1 colspan=1>38.20%</td><td rowspan=1 colspan=1>国有法人</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>安徽省文化旅游产业投资基金</td><td rowspan=1 colspan=1>8.60%</td><td rowspan=1 colspan=1>国有法人</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>香港中央结算有限公司</td><td rowspan=1 colspan=1>5.40%</td><td rowspan=1 colspan=1>境外法人</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>全国社保基金——六组合</td><td rowspan=1 colspan=1>3.20%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>中国旅游集团产业基金</td><td rowspan=1 colspan=1>2.40%</td><td rowspan=1 colspan=1>境内非国有法人</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>基本养老保险基金八零六组合</td><td rowspan=1 colspan=1>1.80%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>中国人寿保险一传统险产品</td><td rowspan=1 colspan=1>1.50%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>华夏中证旅游ETF</td><td rowspan=1 colspan=1>1.20%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>富国中证旅游主题基金</td><td rowspan=1 colspan=1>1.10%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>华泰柏瑞沪深300ETF</td><td rowspan=1 colspan=1>0.90%</td><td rowspan=1 colspan=1>其他</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>前十大股东合计</td><td rowspan=1 colspan=1>64.30%</td><td rowspan=1 colspan=1></td></tr></table>

公司控股股东为翠微文旅集团有限公司，系黄山市人民政府国有资产监督管理委员会全资企业，实际控制人为黄山市国有资产监督管理委员会。

## 第十节 财务报告

## 一、审计意见

公司2025年度财务报表业经中衡会计师事务所(特殊普通合伙）审计，并于2026年3月出具了标准无保留意见（中衡审字[2026]第0579号）。审计机构认为：公司财务报表在所有重大方面按照企业会计准则的规定编制，公允反映了公司2025年12月31日的合并及公司财务状况以及2025年度的合并及公司经营成果和

现金流量。

## 二、合并资产负债表主要项目（摘要）

资产负债表主要项目
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>期末（亿元）</td><td rowspan=1 colspan=1>期初(亿元）</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>8.20</td><td rowspan=1 colspan=1>7.60</td></tr><tr><td rowspan=1 colspan=1>应收账款及合同资产</td><td rowspan=1 colspan=1>1.80</td><td rowspan=1 colspan=1>1.70</td></tr><tr><td rowspan=1 colspan=1>存货</td><td rowspan=1 colspan=1>0.60</td><td rowspan=1 colspan=1>0.55</td></tr><tr><td rowspan=1 colspan=1>固定资产及在建工程</td><td rowspan=1 colspan=1>24.60</td><td rowspan=1 colspan=1>23.80</td></tr><tr><td rowspan=1 colspan=1>其他资产</td><td rowspan=1 colspan=1>5.40</td><td rowspan=1 colspan=1>5.15</td></tr><tr><td rowspan=1 colspan=1>资产总计</td><td rowspan=1 colspan=1>40.60</td><td rowspan=1 colspan=1>38.80</td></tr><tr><td rowspan=1 colspan=1>应付账款及应付票据</td><td rowspan=1 colspan=1>2.40</td><td rowspan=1 colspan=1>2.20</td></tr><tr><td rowspan=1 colspan=1>合同负债</td><td rowspan=1 colspan=1>3.80</td><td rowspan=1 colspan=1>3.40</td></tr><tr><td rowspan=1 colspan=1>借款及其他负债</td><td rowspan=1 colspan=1>5.10</td><td rowspan=1 colspan=1>5.00</td></tr><tr><td rowspan=1 colspan=1>负债合计</td><td rowspan=1 colspan=1>11.30</td><td rowspan=1 colspan=1>10.60</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东权益合计</td><td rowspan=1 colspan=1>29.30</td><td rowspan=1 colspan=1>28.20</td></tr></table>

注：上述为合并口径主要项目摘要，完整资产负债表及附注以公司指定信息披露媒体披露的版本为准。

## 三、合并利润表主要项目（摘要)

## 利润表主要项目

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2025年(亿元）</td><td rowspan=1 colspan=1>2024年（亿元）</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>12.80</td><td rowspan=1 colspan=1>11.20</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>5.35</td><td rowspan=1 colspan=1>4.73</td></tr><tr><td rowspan=1 colspan=1>期间费用合计</td><td rowspan=1 colspan=1>2.84</td><td rowspan=1 colspan=1>2.60</td></tr><tr><td rowspan=1 colspan=1>研发费用（含于期间费用）</td><td rowspan=1 colspan=1>0.35</td><td rowspan=1 colspan=1>0.30</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的净利润</td><td rowspan=1 colspan=1>3.02</td><td rowspan=1 colspan=1>2.68</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的扣除非经常性损益的净利润</td><td rowspan=1 colspan=1>2.86</td><td rowspan=1 colspan=1>2.54</td></tr></table>

## 四、合并现金流量表主要项目（摘要）

现金流量表主要项目
<table><tr><td rowspan=2 colspan=1>项目经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>2025年(亿元)</td><td rowspan=1 colspan=1>2024年(亿元)</td></tr><tr><td rowspan=1 colspan=1>4.50</td><td rowspan=1 colspan=1>4.00</td></tr><tr><td rowspan=1 colspan=1>投资活动产生的现金流量净额</td><td rowspan=1 colspan=1>-1.60</td><td rowspan=1 colspan=1>-1.40</td></tr><tr><td rowspan=1 colspan=1>筹资活动产生的现金流量净额</td><td rowspan=1 colspan=1>0.40</td><td rowspan=1 colspan=1>0.50</td></tr></table>

公司执行财政部颁布的企业会计准则及相关规定，主要会计政策与上一年度保持一致，报告期内无重大会计估计变更。

## 备查文件目录

载有公司法定代表人、主管会计工作负责人、会计机构负责人签名并盖章的财务报表。

载有会计师事务所盖章、注册会计师签名并盖章的2025年度审计报告原件。

·报告期内公开披露过的所有公司文件的正本及公告原稿。

公司2025年年度股东大会会议资料及决议。

(本报告为模拟数据，仅供研究测试使用，不构成任何投资建议)