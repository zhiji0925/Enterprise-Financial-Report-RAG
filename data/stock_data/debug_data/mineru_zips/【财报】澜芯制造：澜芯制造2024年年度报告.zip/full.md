# 澜芯制造

# 2024年年度报告

(股票简称：澜芯制造股票代码：688298.SH)

披露日期：2025年03月27日

第一节公司简介  
第二节主要会计数据和财务指标  
第三节 管理层讨论与分析  
第四节重要事项  
第五节风险因素  
第六节财务报表摘要

## 目录

## 第一节 公司简介

澜芯半导体制造股份有限公司(证券简称：澜芯制造，A股代码688298.SH，H股代码02166.HK，以下简称“公司”）成立于2005年，总部位于江苏省无锡市，系中国大陆规模第二大的纯晶圆代工企业(仅次于中芯国际，错位竞合）。公司聚焦28nm及以上成熟制程节点，构建BCD电源管理、功率器件、CIS图像传感器、MCU嵌入式控制、射频五大特色工艺平台，向全球500余家芯片设计公司提供8英寸与12英寸晶圆代工及配套服务。

公司发展历程：2010年无锡8英寸特色工艺产线投产，以功率器件与BCD代工起家；2018年合肥12英寸产线建成量产，制程能力延伸至55/40/28nm；2021年于上海证券交易所科创板上市；2022年增发H股在香港联合交易所上市，形成A+H双融资平台。截至2024年12月31日，公司注册资本16.80亿元（A股12.00亿股、H股4.80亿股)，员工总数约13,500人，其中研发人员约3,100人。

表1：公司生产基地与产能布局(截至2024年末)
<table><tr><td rowspan=1 colspan=1>基地</td><td rowspan=1 colspan=1>晶圆规格</td><td rowspan=1 colspan=1>月产能</td><td rowspan=1 colspan=1>主要工艺平台</td><td rowspan=1 colspan=1>状态</td></tr><tr><td rowspan=1 colspan=1>无锡Fab1</td><td rowspan=1 colspan=1>8英寸</td><td rowspan=1 colspan=1>12.0万片</td><td rowspan=1 colspan=1>BCD、功率器件、CIS、射频</td><td rowspan=1 colspan=1>量产</td></tr><tr><td rowspan=1 colspan=1>合肥Fab2</td><td rowspan=1 colspan=1>12英寸</td><td rowspan=1 colspan=1>9.5万片</td><td rowspan=1 colspan=1>55/40/28nm CIS、MCU、嵌入式</td><td rowspan=1 colspan=1>量产</td></tr><tr><td rowspan=1 colspan=1>武汉Fab3</td><td rowspan=1 colspan=1>12英寸</td><td rowspan=1 colspan=1>5.0万片（一期）</td><td rowspan=1 colspan=1>车规功率、高压BCD</td><td rowspan=1 colspan=1>在建，预计26Q2投产</td></tr></table>

资料来源：公司公告

公司治理：董事会由9名董事组成（含3名独立非执行董事），下设审计、薪酬与考核、战略等专门委员会。报告期内公司治理运作规范，信息披露连续获得交易所信息披露考评A级。公司控股股东为无锡澜创产业投资集团有限公司，持股比例23.6%，无实际控制人层面的股权质押情形

公司控股股东与子公司情况：截至2024年12月31日，控股股东无锡澜创产业投资集团有限公司直接持有公司23.6%股份，无锡市产业发展投资基金持有8.5%股份，H股股份由香港中央结算（代理人）有限公司名义持有。公司主要控股子公司均为全资平台，围绕三个生产基地与海外业务布局：

表2：主要控股参股子公司情况
<table><tr><td rowspan=1 colspan=1>子公司名称</td><td rowspan=1 colspan=1>持股比例</td><td rowspan=1 colspan=1>注册资本(亿元)</td><td rowspan=1 colspan=1>主要业务</td></tr><tr><td rowspan=1 colspan=1>无锡澜芯制造运营有限公司</td><td rowspan=1 colspan=1>100%</td><td rowspan=1 colspan=1>15.0</td><td rowspan=1 colspan=1>8英寸产线运营与研发</td></tr><tr><td rowspan=1 colspan=1>合肥澜芯集成电路有限公司</td><td rowspan=1 colspan=1>100%</td><td rowspan=1 colspan=1>20.0</td><td rowspan=1 colspan=1>12英寸产线运营与研发</td></tr><tr><td rowspan=1 colspan=1>武汉澜芯半导体制造有限公司</td><td rowspan=1 colspan=1>100%</td><td rowspan=1 colspan=1>30.0</td><td rowspan=1 colspan=1>武汉Fab3建设与运营主体</td></tr><tr><td rowspan=1 colspan=1>澜芯国际（香港）贸易有限公司</td><td rowspan=1 colspan=1>100%</td><td rowspan=1 colspan=1>0.5</td><td rowspan=1 colspan=1>海外采购与销售平台</td></tr></table>

资料来源：公司2024年年度报告

员工情况：截至2024年12月31日，公司在职员工13,468人，其中研发人员3,102人、生产人员7,643人、销售与市场人员846人、管理人员及其他1,877人；本科及以上学历占比41.3%，国家级与省级人才计划入选者合计12人。报告期内人均培训时长56小时，核心骨于年流失率低于3%，员工结构保持稳定。

表3：公司员工专业结构（2024年末）
<table><tr><td colspan="1" rowspan="1">人员类别</td><td colspan="1" rowspan="1">人数(人)</td><td colspan="1" rowspan="1">占比</td><td colspan="1" rowspan="1">较上年变动</td></tr><tr><td colspan="1" rowspan="1">研发人员</td><td colspan="1" rowspan="1">3,102</td><td colspan="1" rowspan="1">23.0%</td><td colspan="1" rowspan="1">+312人</td></tr><tr><td colspan="1" rowspan="1">生产人员</td><td colspan="1" rowspan="1">7,643</td><td colspan="1" rowspan="1">56.8%</td><td colspan="1" rowspan="1">+298人</td></tr><tr><td colspan="1" rowspan="1">销售与市场人员</td><td colspan="1" rowspan="1">846</td><td colspan="1" rowspan="1">6.3%</td><td colspan="1" rowspan="1">+56人</td></tr><tr><td colspan="1" rowspan="1">管理人员及其他</td><td colspan="1" rowspan="1">1,877</td><td colspan="1" rowspan="1">13.9%</td><td colspan="1" rowspan="1">+75人</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">13,468</td><td colspan="1" rowspan="1">100%</td><td colspan="1" rowspan="1">+741人</td></tr></table>

资料来源：公司2024年年度报告

表4：公司发展沿革
<table><tr><td rowspan=1 colspan=1>时间</td><td rowspan=1 colspan=1>里程碑事件</td></tr><tr><td rowspan=1 colspan=1>2005年</td><td rowspan=1 colspan=1>公司在江苏省无锡市注册成立，定位纯晶圆代工</td></tr><tr><td rowspan=1 colspan=1>2010年</td><td rowspan=1 colspan=1>无锡8英寸特色工艺产线投产，以功率器件与BCD代工起步</td></tr><tr><td rowspan=1 colspan=1>2015年</td><td rowspan=1 colspan=1>启动车规质量体系建设，导入IATF16949与零缺陷文化</td></tr><tr><td rowspan=1 colspan=1>2016年</td><td rowspan=1 colspan=1>0.18微米BCD平台全系列量产，进入头部消费类客户供应链</td></tr><tr><td rowspan=1 colspan=1>2018年</td><td rowspan=1 colspan=1>合肥12英寸产线建成量产，制程延伸至55/40/28nm</td></tr><tr><td rowspan=1 colspan=1>2020年</td><td rowspan=1 colspan=1>车规CIS平台通过AEC-Q100认证，进入前装供应链</td></tr><tr><td rowspan=1 colspan=1>2021年</td><td rowspan=1 colspan=1>于上海证券交易所科创板上市，募资投向合肥12英寸扩产</td></tr><tr><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>增发H股在香港联交所上市，形成A+H双融资平台</td></tr><tr><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>行业去库存周期中稼动率承压，车规与工业结构逆势提升</td></tr><tr><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>营业收入85.3亿元创历史新高；武汉Fab3开工建设</td></tr></table>

资料来源：公司2024年年度报告

公司核心管理团队平均拥有二十年以上晶圆制造产业经验，董事长兼首席执行官具备跨国晶圆厂完整运营经历；报告期内公司实施了两期员工持股计划，覆盖核心技术与管理骨干约1,800人，绑定长期成长。

行业地位与荣誉：公司为中国半导体行业协会副理事长单位，2024年再次位列全球晶圆代工企业营收规模前十（以特色工艺口径计居大陆第二）；报告期内无锡基地获评国家级绿色工厂、江苏省智能制造示范工厂，无锡Fab1被评为江苏省示范智能车间，“车规CIS平台开发与产业化”项目获江苏省科学技术进步一等奖。公司牵头承担国家科技重大专项课题2项，累计参与制定行业标准11项，在BCD与车规特色工艺领域的行业话语权持续提升。

薪酬与激励：公司建立“基本薪酬+绩效奖金+中长期激励”相结合的薪酬体系，报告期内人均薪酬约13.5万元，同比增长6.5%；研发人员薪酬带宽对标行业75分位，核心技术骨干实行差异化薪酬政策。投资者关系方面，报告期内公司组织业绩说明会4场、接待现场与电话调研87场次，覆盖机构投资者超过500家，上证e互动年度回复率100%，连续两年获评科创板公司投资者关系管理优秀案例。

## 第二节 主要会计数据和财务指标

2024年公司经营质效全面提升，营业收入创历史新高，盈利能力显著修复。公司实现营业收入85.30亿元，同比增长19.31%；归属于上市公司股东的净利润8.90亿元，同比增长23.61%；经营活动产生的现金流量净额42.30亿元，同比增长14.95%。主要系下游消费、工业补库与汽车电子放量共振，稼动率由年初80.2%回升至年末92.4%，产品结构向高压BCD与车规迁移所致。

表5：近三年主要会计数据（单位：人民币百万元）
<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">2022年</td><td colspan="1" rowspan="1">2023年</td><td colspan="1" rowspan="1">2024年</td><td colspan="1" rowspan="1">本期比上年增減</td></tr><tr><td colspan="1" rowspan="1">营业收入</td><td colspan="1" rowspan="1">6,820</td><td colspan="1" rowspan="1">7,150</td><td colspan="1" rowspan="1">8,530</td><td colspan="1" rowspan="1">+19.31%</td></tr><tr><td colspan="1" rowspan="1">归属于上市公司股东的净利润</td><td colspan="1" rowspan="1">960</td><td colspan="1" rowspan="1">720</td><td colspan="1" rowspan="1">890</td><td colspan="1" rowspan="1">+23.61%</td></tr><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">2022年</td><td colspan="1" rowspan="1">2023年</td><td colspan="1" rowspan="1">2024年</td><td colspan="1" rowspan="1">本期比上年增减</td></tr><tr><td colspan="1" rowspan="1">扣除非经常性损益的净利润</td><td colspan="1" rowspan="1">840</td><td colspan="1" rowspan="1">590</td><td colspan="1" rowspan="1">742</td><td colspan="1" rowspan="1">+25.42%</td></tr><tr><td colspan="1" rowspan="1">经营活动产生的现金流量净额</td><td colspan="1" rowspan="1">3,850</td><td colspan="1" rowspan="1">3,680</td><td colspan="1" rowspan="1">4,230</td><td colspan="1" rowspan="1">+14.95%</td></tr><tr><td colspan="1" rowspan="1">归属于上市公司股东的净资产</td><td colspan="1" rowspan="1">20,580</td><td colspan="1" rowspan="1">21,940</td><td colspan="1" rowspan="1">23,210</td><td colspan="1" rowspan="1">+5.79%</td></tr><tr><td colspan="1" rowspan="1">总资产</td><td colspan="1" rowspan="1">29,560</td><td colspan="1" rowspan="1">33,620</td><td colspan="1" rowspan="1">38,650</td><td colspan="1" rowspan="1">+14.96%</td></tr></table>

资料来源：公司2024年年度报告(经审计)

表6：2024年分季度主要财务数据（单位：人民币百万元）
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>第一季度</td><td rowspan=1 colspan=1>第二季度</td><td rowspan=1 colspan=1>第三季度</td><td rowspan=1 colspan=1>第四季度</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>1,850</td><td rowspan=1 colspan=1>2,120</td><td rowspan=1 colspan=1>2,160</td><td rowspan=1 colspan=1>2,400</td></tr><tr><td rowspan=1 colspan=1>归属于上市公司股东的净利润</td><td rowspan=1 colspan=1>190</td><td rowspan=1 colspan=1>210</td><td rowspan=1 colspan=1>220</td><td rowspan=1 colspan=1>270</td></tr><tr><td rowspan=1 colspan=1>经营活动产生的现金流量净额</td><td rowspan=1 colspan=1>810</td><td rowspan=1 colspan=1>960</td><td rowspan=1 colspan=1>1,120</td><td rowspan=1 colspan=1>1,340</td></tr><tr><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>23.8%</td><td rowspan=1 colspan=1>25.1%</td><td rowspan=1 colspan=1>26.4%</td><td rowspan=1 colspan=1>27.2%</td></tr><tr><td rowspan=1 colspan=1>产能利用率</td><td rowspan=1 colspan=1>80.2%</td><td rowspan=1 colspan=1>85.6%</td><td rowspan=1 colspan=1>88.9%</td><td rowspan=1 colspan=1>92.4%</td></tr></table>

资料来源：公司2024年年度报告(经审计)

表7：近三年主要财务指标
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2022年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>2024年</td></tr><tr><td rowspan=1 colspan=1>基本每股收益（元）</td><td rowspan=1 colspan=1>0.57</td><td rowspan=1 colspan=1>0.43</td><td rowspan=1 colspan=1>0.53</td></tr><tr><td rowspan=1 colspan=1>每股经营活动现金流量净额（元）</td><td rowspan=1 colspan=1>2.29</td><td rowspan=1 colspan=1>2.19</td><td rowspan=1 colspan=1>2.52</td></tr><tr><td rowspan=1 colspan=1>加权平均净资产收益率</td><td rowspan=1 colspan=1>4.6%</td><td rowspan=1 colspan=1>3.2%</td><td rowspan=1 colspan=1>3.9%</td></tr><tr><td rowspan=1 colspan=1>毛利率</td><td rowspan=1 colspan=1>29.5%</td><td rowspan=1 colspan=1>25.3%</td><td rowspan=1 colspan=1>26.1%</td></tr><tr><td rowspan=1 colspan=1>资产负债率（%)</td><td rowspan=1 colspan=1>32.5</td><td rowspan=1 colspan=1>35.0</td><td rowspan=1 colspan=1>37.7</td></tr><tr><td rowspan=1 colspan=1>研发投入占营业收入比例</td><td rowspan=1 colspan=1>10.4%</td><td rowspan=1 colspan=1>11.0%</td><td rowspan=1 colspan=1>10.8%</td></tr></table>

资料来源：公司2024年年度报告(经审计)

2024年度公司非经常性损益合计1.48亿元，占归母净利润的比例为16.6%，主要包括：计入当期损益的政府补助(与收益相关的产业扶持及研发专项资金）1.02亿元、理财及利息增值收益0.29亿元、股权处置与公允价值变动等其他项目0.17亿元。扣除非经常性损益后，2023年、2024年扣非净利润分别为5.90亿元、7.42亿元，反映主营业务盈利的真实修复斜率。

## 第三节 管理层讨论与分析

(一)行业情况。2024年全球晶圆代工市场规模约1,150亿美元，同比增长约9%，行业自2023年去库存周期后温和复苏。结构性分化明显：先进制程受AI算力需求拉动供不应求；成熟制程上半年承压、下半年起稼动率与价格先后回暖，其中特色工艺（BCD、功率、CIS）受益于汽车电子与工业能源转型需求，景气度领先于标准逻辑制程。中国大陆晶圆代工产能占全球比重持续提升，设计公司供应链本土化意愿显著增强，国产特色工艺代工产能成为稀缺资源。

从国内产业环境看，2024年中国大陆晶圆代工产能(8英寸约当）约占全球四分之一以上，境内晶圆厂资本开支中约六成投向成熟制程与特色工艺平台。公司无锡、合肥、武汉三个基地形成覆盖华东与华中的产业纵深，贴近国内八成以上特色工艺设计公司的总部所在地，配套材料、特种气体与封装测试资源完善物流与客户协同效率构成区域优势。

(二）经营回顾。报告期内公司晶圆出货量368万片(8英寸约当)，同比增长11.5%；综合稼动率87.2%，其中第四季度达92.4%；营业收入85.30亿元创历史新高，同比增长19.31%。公司在手订单与合同负债自二季度起持续回升，年末存货21.4亿元，较三季度末下降6.2%，存货周转天数降至68天，处于健康区间。

表8：2024年营业收入按工艺平台拆分
<table><tr><td rowspan=1 colspan=1>工艺平台</td><td rowspan=1 colspan=1>收入（亿元）</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>同比增速</td></tr><tr><td rowspan=1 colspan=1>BCD电源管理</td><td rowspan=1 colspan=1>32.4</td><td rowspan=1 colspan=1>38%</td><td rowspan=1 colspan=1>+31%</td></tr><tr><td rowspan=1 colspan=1>功率器件</td><td rowspan=1 colspan=1>18.8</td><td rowspan=1 colspan=1>22%</td><td rowspan=1 colspan=1>+24%</td></tr><tr><td rowspan=1 colspan=1>CIS图像传感</td><td rowspan=1 colspan=1>12.8</td><td rowspan=1 colspan=1>15%</td><td rowspan=1 colspan=1>+16%</td></tr><tr><td rowspan=1 colspan=1>MCU及嵌入式</td><td rowspan=1 colspan=1>10.2</td><td rowspan=1 colspan=1>12%</td><td rowspan=1 colspan=1>+2%</td></tr><tr><td rowspan=1 colspan=1>射频</td><td rowspan=1 colspan=1>6.8</td><td rowspan=1 colspan=1>8%</td><td rowspan=1 colspan=1>+4%</td></tr><tr><td rowspan=1 colspan=1>其他（掩模、测试配套等）</td><td rowspan=1 colspan=1>4.3</td><td rowspan=1 colspan=1>5%</td><td rowspan=1 colspan=1>+6%</td></tr></table>

资料来源：公司2024年年度报告

表9：2024年营业收入按下游应用拆分
<table><tr><td rowspan=1 colspan=1>应用领域</td><td rowspan=1 colspan=1>收入(亿元)</td><td rowspan=1 colspan=1>占比</td><td rowspan=1 colspan=1>变化</td></tr><tr><td rowspan=1 colspan=1>消费电子</td><td rowspan=1 colspan=1>29.0</td><td rowspan=1 colspan=1>34%</td><td rowspan=1 colspan=1>占比-3pct</td></tr><tr><td rowspan=1 colspan=1>汽车电子</td><td rowspan=1 colspan=1>22.2</td><td rowspan=1 colspan=1>26%</td><td rowspan=1 colspan=1>占比+4pct</td></tr><tr><td rowspan=1 colspan=1>工业控制</td><td rowspan=1 colspan=1>18.8</td><td rowspan=1 colspan=1>22%</td><td rowspan=1 colspan=1>占比持平</td></tr><tr><td rowspan=1 colspan=1>通讯</td><td rowspan=1 colspan=1>10.2</td><td rowspan=1 colspan=1>12%</td><td rowspan=1 colspan=1>占比持平</td></tr><tr><td rowspan=1 colspan=1>计算及其他</td><td rowspan=1 colspan=1>5.1</td><td rowspan=1 colspan=1>6%</td><td rowspan=1 colspan=1>占比-1pct</td></tr></table>

资料来源：公司2024年年度报告

分季度看，公司经营节奏逐季走强：一季度受春节假期与行业去库存尾声影响，收入18.5亿元、稼动率80.2%；二季度起工业与汽车客户补库启动，稼动率回升至85.6%；四季度消费电子旺季与BCD提价共振，单季收入24.0亿元创历史新高、稼动率92.4%。全年出货368万片(8英寸约当），平均售价同比提升约7%，呈现量价同步修复。

(三）销售模式与客户情况。公司采用直销为主的销售模式，晶圆代工业务收入82.4亿元，其他业务（掩模制造、测试配套等）收入2.9亿元。客户以Fabless设计公司与IDM外协订单为主，前五大客户收入占比41.2%，无单一客户占比超过15%，客户分散度优于行业平均水平；长协订单覆盖约六成产能，为稼动率稳定性提供保障。

报告期内公司新增客户86家，覆盖欧洲工业、国内新能源车企芯片供应商与AI服务器电源等新领域；合作满三年客户的续单比例超过92%。按区域划分，境内收入占比约83%，海外及出口交付收入占比约17%，其中欧洲工业客户收入同比增长超过40%，是海外增量的主要来源。

表10：前五大客户销售情况（2024年）
<table><tr><td colspan="1" rowspan="1">客户</td><td colspan="1" rowspan="1">销售金额（亿元）</td><td colspan="1" rowspan="1">占年度销售比例</td><td colspan="1" rowspan="1">销售内容</td></tr><tr><td colspan="1" rowspan="1">客户一(境内消费类设计公司)</td><td colspan="1" rowspan="1">10.7</td><td colspan="1" rowspan="1">12.6%</td><td colspan="1" rowspan="1">BCD电源管理</td></tr><tr><td colspan="1" rowspan="1">客户二（境内工业芯片设计公司）</td><td colspan="1" rowspan="1">9.8</td><td colspan="1" rowspan="1">11.5%</td><td colspan="1" rowspan="1">BCD、MCU嵌入式</td></tr><tr><td colspan="1" rowspan="1">客户三（境内功率器件IDM)</td><td colspan="1" rowspan="1">6.4</td><td colspan="1" rowspan="1">7.5%</td><td colspan="1" rowspan="1">IGBT、SJ MOSFET</td></tr><tr><td colspan="1" rowspan="1">客户四(境内车载CIS设计公司）</td><td colspan="1" rowspan="1">4.5</td><td colspan="1" rowspan="1">5.3%</td><td colspan="1" rowspan="1">车规CIS</td></tr><tr><td colspan="1" rowspan="1">客户五（欧洲工业集团）</td><td colspan="1" rowspan="1">3.7</td><td colspan="1" rowspan="1">4.3%</td><td colspan="1" rowspan="1">分立器件、BCD</td></tr><tr><td colspan="1" rowspan="1">合计</td><td colspan="1" rowspan="1">35.1</td><td colspan="1" rowspan="1">41.2%</td><td colspan="1" rowspan="1"></td></tr></table>

资料来源：公司2024年年度报告（客户名称按披露规则隐匿）

(四)核心竞争力分析。其一，特色工艺平台的量产深度。BCD平台完成0.18微米至90nm全系列覆盖，客户留存率超过95%；高压BCD(700V以上）国内具备量产能力的代工厂极少；车规CIS通过AEC-Q100认证并进入前装供应链，此类认证周期通常2-3年，一旦通过即形成强绑定。工艺知识以量产数据形态沉淀于产线与设备，同业短期内难以复制

其二，客户结构与生态粘性。公司服务超过500家设计公司，车规与工业客户合计超230家，与主要客户的平均合作年限超过八年。特色工艺代工的转换成本极高（重新流片、重新认证、良率重爬坡），客户粘性显著高于标准逻辑代工，公司订单可预测性亦因此优于行业。

其三，A+H双融资平台带来的资金确定性。2022年H股上市后公司综合融资成本低于境内同业，报告期末货币资金78.5亿元、资产负债率37.7%，为武汉Fab3一期约110亿元投资提供充沛的内源资金；对比单一融资平台，公司在产能扩张窗口期的资金确定性更强

其四，质量体系与运营效率。公司自2015年起建设零缺陷质量文化与IATF16949车规体系，2024年客户投诉率同比下降21%，8英寸整体良率提升0.8个百分点；无锡基地单位晶圆制造成本较行业均值低约5%，成本管控能力在稼动率回升周期中直接转化为利润弹性。

(五)盈利与成本。2024年综合毛利率26.1%，同比提升0.8个百分点；分季度自23.8%逐季回升至27.2%，主因稼动率回升摊薄固定成本、8英寸BCD与功率产品于四季度温和提价3%-5%、以及高毛利车规产品占比提升。公司严控期间费用，销售、管理、研发、财务费用率合计14.3%，同比下降0.8个百分点；财务费用因H股募资到位后利息收入增加而转负。

(六）研发投入。报告期内研发投入9.20亿元，占营业收入10.8%，同比增长16.5%，其中资本化比例较低。重点投向：车规CIS二代平台、0.13微米高压BCD平台、武汉Fab3车规功率工艺套件、12英寸嵌入式存储工艺、以及6英寸SiC中试线前期工作。截至年末，公司累计获得授权发明专利2,850件，参与制定行业标准11项。主要在研项目进展如下：

表11：主要研发项目进展（2024年）
<table><tr><td rowspan=1 colspan=1>研发项目</td><td rowspan=1 colspan=1>当前阶段</td><td rowspan=1 colspan=1>本期投入（亿元）</td><td rowspan=1 colspan=1>预计完成/量产时间</td></tr><tr><td rowspan=1 colspan=1>车规CIS二代平台（堆栈式）</td><td rowspan=1 colspan=1>工艺导入</td><td rowspan=1 colspan=1>1.8</td><td rowspan=1 colspan=1>2025年下半年</td></tr><tr><td rowspan=1 colspan=1>0.13微米高压BCD平台</td><td rowspan=1 colspan=1>客户验证</td><td rowspan=1 colspan=1>1.5</td><td rowspan=1 colspan=1>2025年</td></tr><tr><td rowspan=1 colspan=1>武汉Fab3车规功率工艺套件</td><td rowspan=1 colspan=1>开发中</td><td rowspan=1 colspan=1>2.2</td><td rowspan=1 colspan=1>2026年（随Fab3投产）</td></tr><tr><td rowspan=1 colspan=1>12英寸嵌入式存储工艺</td><td rowspan=1 colspan=1>风险试产</td><td rowspan=1 colspan=1>1.1</td><td rowspan=1 colspan=1>2026年</td></tr><tr><td rowspan=1 colspan=1>6英寸SiC工艺中试线</td><td rowspan=1 colspan=1>筹建</td><td rowspan=1 colspan=1>0.9</td><td rowspan=1 colspan=1>2026年</td></tr></table>

资料来源：公司2024年年度报告(上述五个重点项目本期投入合计7.5亿元，占研发投入的81.5%，其余为量产工艺优化与预研项目)

(七)现金流与资本开支。经营活动现金流净额42.30亿元，为净利润的4.8倍；投资活动现金流出主要为资本开支，全年实际资本开支48.3亿元，其中约六成投向武汉Fab3土建与首批设备预订，其余投向合肥12英寸CIS扩产与无锡8英寸车规技改。公司资本开支强度（占收入57%）处于同业高位，反映特色工艺扩产窗口期的主动布局。

(八）2025年经营计划。公司2025年度经营目标：营业收入同比增长10%-15%，产能利用率维持90%以上，资本开支约55亿元(其中约七成投向武汉Fab3）。武汉Fab3一期规划月产能5万片，聚焦车规功率与高压BCD平台，预计2026年二季度投产，达产后预计新增年收入约35亿元。公司将同步推进SiC中试线建设、海外工业客户拓展与质量体系升级。

(九）质量体系与中长期战略。质量方面，报告期内公司整体晶圆良率稳中有升，8英寸平台综合良率同比提升0.8个百分点，客户投诉率同比下降21%，批量质量退货率维持在0.3%以下的行业优秀水平；车规产线执行“零缺陷”标准，累计通过AEC-Q100认证的产品料号达47个，IATF16949体系持续覆盖无锡、合肥两大基地，武汉Fab3将按车规标准同步建线。

中长期战略方面，公司坚持“特色工艺纵深化”主线：一是深耕BCD、功率、CIS、MCU、射频五大平台的器件结构与工艺集成创新，巩固高端特色工艺稀缺产能地位；二是以武汉Fab3投产为契机，力争2027年将车规与工业应用收入占比提升至45%以上，建设大陆领先的车规芯片制造平台；三是建设6英寸SiC工艺中试线，前瞻布局化合物半导体；四是发挥A+H双融资平台优势，保持研发与产能高强度投入，实现长期股东回报。

(十）可能与经营目标相关的风险。若下游消费电子复苏中断、成熟制程价格竞争加剧，或武汉Fab3投产进度不及预期，上述经营目标存在不能实现的风险，详见第五节。

## 第四节 重要事项

(一)利润分配方案。公司2024年度利润分配预案为：以总股本16.80亿股为基数，每10股派发现金红利1.80元(含税)，合计派发现金红利3.02亿元，占2024年度归母净利润的33.9%，不送股、不以资本公积转增股本。公司已连续三年提升现金分红比例，A/H股股东享有同等分配权利。

（二）重大投资建设。武汉Fab3项目（12英寸，一期月产能5万片）规划总投资约110亿元，报告期内累计投入约32亿元，完成洁净厂房主体建设，主要工艺设备已预订；项目达产后预计新增年收入约35亿元，主要面向车规功率与高压BCD平台。公司同时决议投资建设无锡基地6英寸SiC工艺中试线，预计投资规模约3.5亿元。

（三）关联交易情况。报告期内公司日常关联交易主要为向关联方采购特气、配套服务与向关联产业园区租赁厂房，交易金额合计1.21亿元，占同类交易比例约2.4%，定价遵循市场公允原则，相关议案已经董事会及股东大会审议通过。

(四)承诺履行情况。公司控股股东、实际控制人及持股5%以上股东严格履行上市时作出的股份锁定、避免同业竞争等承诺，报告期内不存在违反承诺的情形。公司H股增发募集资金已按披露用途使用完毕。

（五）审计情况。公司2024年度财务报告经中衡会计师事务所(特殊普通合伙）审计，并出具了标准无保留意见的审计报告。报告期内公司不存在被出具非标意见的情形。

(六）其他重大事项。报告期内公司入选恒生综合指数成分股；完成员工持股计划第二期授予；不存在重大诉讼、仲裁或行政处罚事项；未发生对持续经营有重大影响的重大安全事故。

(七)政府补助与税收优惠。报告期内公司计入当期损益的政府补助合计1.02亿元，其中与产业扶持相关的补助资金0.61亿元、研发专项补助0.41亿元；合肥澜芯集成电路有限公司、武汉澜芯半导体制造有限公司为高新技术企业，适用15%企业所得税优惠税率；武汉Fab3项目已纳入湖北省省级重大项目库，在用地、用能等要素保障及中长期贷款贴息方面获得政策支持。

(八）期后事项。除本报告“第四节（一）”所述利润分配预案（已于2025年3月27日经公司第四届董事会第八次会议审议通过）外，自资产负债表日至本报告披露日，公司不存在其他应披露的重大期后事项。

(九)环境、社会责任与公司治理（ESG)。环境维度：公司持续推进绿色制造，2024年单位晶圆综合能耗同比下降4.2%，无锡基地再生水回用率达78%，合肥基地获评省级绿色工厂；全年环保投入约1.2亿元，废水、废气排放指标全部优于国家及地方标准。社会责任与治理维度：公司依法纳税，2024年缴纳税费合计6.8亿元；安全生产投入8,600万元，员工培训投入4,200万元；与东南大学、江南大学共建联合实验室并设立“澜芯奖学金”，累计资助学生超过600名。

报告期内公司召开董事会9次、股东大会4次，独立董事对关联交易、对外担保等事项发表独立意见；信息披露工作连续获上海证券交易所考评A级。董事会战略委员会已将ESG管理纳入审议范围，公司计划于2025年披露首份ESG专项报告，推动绿色制造与规范治理水平持续提升。

## 第五节 风险因素

(一）宏观经济与下游需求波动风险。公司产品下游覆盖消费电子、汽车、工业等广泛领域，若宏观经济增长放缓导致终端需求疲弱，晶圆代工稼动率与产品价格可能承压，公司收入与毛利率存在不及预期的风险。

(二）行业竞争加剧风险。全球成熟制程代工产能集中扩产，境内同业在8英寸特色工艺与12英寸成熟制程上加大投资，若价格竞争加剧，公司可能被迫下调产品价格，影响盈利能力。

(三）新产能建设与爬坡风险。武汉Fab3投资规模大、建设周期长，存在建设进度延迟、设备交付受限、投产初期良率与稼动率爬坡不及预期的风险；达产后若下游需求不及预期，新增折旧将侵蚀利润率。

(四）供应链风险。部分高端工艺设备、核心零部件及材料仍依赖境外供应，若相关国家出口管制升级或供应受限，公司扩产与技术升级进度可能受到影响；公司已将国产设备采购比例提升至约45%(按2025年在执行采购合同口径）以缓解该风险。

(五)客户与认证风险。车规、工业类产品认证周期长、投入大，存在认证不通过或客户导入延迟的风险；前五大客户收入占比41.2%，若主要客户订单波动，公司短期业绩可能受到影响。

(六）汇率与海外经营风险。公司存在一定规模的出口收汇与H股融资资金池，人民币汇率波动可能影响折算利润与财务费用；地缘政治与贸易政策变化亦可能对海外客户拓展产生影响。

(七)人才流失风险。晶圆制造与工艺研发高度依赖核心技术骨干与量产经验积累，行业人才竞争日趋激烈。公司通过员工持股计划、有竞争力的薪酬体系与系统性培训保持队伍稳定，报告期核心骨干年流失率低于3%；若未来关键岗位人才流失率上升，可能对公司研发进度与量产良率产生不利影响。

(八）安全生产与环保风险。晶圆制造过程涉及特种气体、湿电子化学品与高纯水系统，存在安全生产与污染物排放管控压力。公司已建立覆盖三个生产基地的EHS管理体系并通过ISO14001、ISO45001认证，报告期内未发生重大安全事故，亦未受到环保行政处罚；随着武汉Fab3建成投产，公司将持续加大安全环保投入，相关风险总体可控。

## 第六节 财务报表摘要

本节列示经审计的2024年度合并财务报表主要项目及简明分析。报告期末，公司合并总资产386.50亿元，归母净资产232.10亿元，资产负债率37.7%，处于同业稳健水平；货币资金充裕，为武汉Fab3后续资本开支与研发投入提供保障。

表12：合并资产负债表主要项目（单位：人民币百万元）
<table><tr><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">2024年12月31日</td><td colspan="1" rowspan="1">项目</td><td colspan="1" rowspan="1">2024年12月31日</td></tr><tr><td colspan="1" rowspan="1">货币资金</td><td colspan="1" rowspan="1">7,850</td><td colspan="1" rowspan="1">短期借款</td><td colspan="1" rowspan="1">1,280</td></tr><tr><td colspan="1" rowspan="1">应收票据及应收账款</td><td colspan="1" rowspan="1">1,420</td><td colspan="1" rowspan="1">应付票据及应付账款</td><td colspan="1" rowspan="1">2,150</td></tr><tr><td colspan="1" rowspan="1">存货</td><td colspan="1" rowspan="1">2,140</td><td colspan="1" rowspan="1">合同负债</td><td colspan="1" rowspan="1">590</td></tr><tr><td colspan="1" rowspan="1">固定资产</td><td colspan="1" rowspan="1">16,580</td><td colspan="1" rowspan="1">长期借款</td><td colspan="1" rowspan="1">5,520</td></tr><tr><td colspan="1" rowspan="1">在建工程</td><td colspan="1" rowspan="1">6,260</td><td colspan="1" rowspan="1">其他负债合计</td><td colspan="1" rowspan="1">5,030</td></tr><tr><td colspan="1" rowspan="1">其他资产合计</td><td colspan="1" rowspan="1">4,400</td><td colspan="1" rowspan="1">负债合计</td><td colspan="1" rowspan="1">14,570</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">一</td><td colspan="1" rowspan="1">归属于母公司股东权益</td><td colspan="1" rowspan="1">23,210</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">少数股东权益</td><td colspan="1" rowspan="1">870</td></tr><tr><td colspan="1" rowspan="1">资产总计</td><td colspan="1" rowspan="1">38,650</td><td colspan="1" rowspan="1">负债和股东权益总计</td><td colspan="1" rowspan="1">38,650</td></tr></table>

资料来源：公司2024年年度报告(经审计)

表13：合并利润表主要项目（单位：人民币百万元）
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>同比</td></tr><tr><td rowspan=1 colspan=1>营业收入</td><td rowspan=1 colspan=1>7,150</td><td rowspan=1 colspan=1>8,530</td><td rowspan=1 colspan=1>+19.31%</td></tr><tr><td rowspan=1 colspan=1>营业成本</td><td rowspan=1 colspan=1>5,341</td><td rowspan=1 colspan=1>6,304</td><td rowspan=1 colspan=1>+18.02%</td></tr><tr><td rowspan=1 colspan=1>毛利</td><td rowspan=1 colspan=1>1,809</td><td rowspan=1 colspan=1>2,226</td><td rowspan=1 colspan=1>+23.05%</td></tr><tr><td rowspan=1 colspan=1>销售费用</td><td rowspan=1 colspan=1>135</td><td rowspan=1 colspan=1>153</td><td rowspan=1 colspan=1>+13.3%</td></tr><tr><td rowspan=1 colspan=1>管理费用</td><td rowspan=1 colspan=1>310</td><td rowspan=1 colspan=1>338</td><td rowspan=1 colspan=1>+9.0%</td></tr><tr><td rowspan=1 colspan=1>研发费用</td><td rowspan=1 colspan=1>760</td><td rowspan=1 colspan=1>862</td><td rowspan=1 colspan=1>+13.4%</td></tr><tr><td rowspan=1 colspan=1>财务费用</td><td rowspan=1 colspan=1>-105</td><td rowspan=1 colspan=1>-163</td><td rowspan=1 colspan=1>利息收入增加</td></tr><tr><td rowspan=1 colspan=1>利润总额</td><td rowspan=1 colspan=1>940</td><td rowspan=1 colspan=1>1,070</td><td rowspan=1 colspan=1>+13.8%</td></tr><tr><td rowspan=1 colspan=1>所得税费用</td><td rowspan=1 colspan=1>210</td><td rowspan=1 colspan=1>168</td><td rowspan=1 colspan=1>-20.0%</td></tr><tr><td rowspan=1 colspan=1>净利润</td><td rowspan=1 colspan=1>730</td><td rowspan=1 colspan=1>902</td><td rowspan=1 colspan=1>+23.6%</td></tr><tr><td rowspan=1 colspan=1>归属于母公司股东的净利润</td><td rowspan=1 colspan=1>720</td><td rowspan=1 colspan=1>890</td><td rowspan=1 colspan=1>+23.61%</td></tr></table>

资料来源：公司2024年年度报告(经审计)

表14：合并现金流量表主要项目（单位：人民币百万元）
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>同比</td></tr><tr><td rowspan=1 colspan=1>经营活动现金流入小计</td><td rowspan=1 colspan=1>7,360</td><td rowspan=1 colspan=1>8,990</td><td rowspan=1 colspan=1>+22.1%</td></tr><tr><td rowspan=1 colspan=1>经营活动现金流量净额</td><td rowspan=1 colspan=1>3,680</td><td rowspan=1 colspan=1>4,230</td><td rowspan=1 colspan=1>+14.95%</td></tr><tr><td rowspan=1 colspan=1>投资活动现金流量净额</td><td rowspan=1 colspan=1>-4,120</td><td rowspan=1 colspan=1>-4,980</td><td rowspan=1 colspan=1>资本开支增加</td></tr><tr><td rowspan=1 colspan=1>筹资活动现金流量净额</td><td rowspan=1 colspan=1>820</td><td rowspan=1 colspan=1>760</td><td rowspan=1 colspan=1>-7.3%</td></tr><tr><td rowspan=1 colspan=1>期末现金及现金等价物余额</td><td rowspan=1 colspan=1>7,840</td><td rowspan=1 colspan=1>7,850</td><td rowspan=1 colspan=1>+0.1%</td></tr><tr><td rowspan=1 colspan=1>购建固定资产等支付的现金（资本开支)</td><td rowspan=1 colspan=1>4,290</td><td rowspan=1 colspan=1>4,830</td><td rowspan=1 colspan=1>+12.6%</td></tr></table>

资料来源：公司2024年年度报告(经审计)  
报告期末主要资产负债项目变动情况如下：

表15：主要资产负债项目变动分析（单位：人民币百万元）

<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2024年末</td><td rowspan=1 colspan=1>2023年末</td><td rowspan=1 colspan=1>变动幅度</td><td rowspan=1 colspan=1>主要原因</td></tr><tr><td rowspan=1 colspan=1>货币资金</td><td rowspan=1 colspan=1>7,850</td><td rowspan=1 colspan=1>7,840</td><td rowspan=1 colspan=1>+0.1%</td><td rowspan=1 colspan=1>H股募资资金沉淀与资本开支支出基本对冲</td></tr><tr><td rowspan=1 colspan=1>存货</td><td rowspan=1 colspan=1>2,140</td><td rowspan=1 colspan=1>2,280</td><td rowspan=1 colspan=1>-6.1%</td><td rowspan=1 colspan=1>下半年出货加快、库存去化良好</td></tr><tr><td rowspan=1 colspan=1>在建工程</td><td rowspan=1 colspan=1>6,260</td><td rowspan=1 colspan=1>4,380</td><td rowspan=1 colspan=1>+42.9%</td><td rowspan=1 colspan=1>武汉Fab3洁净厂房土建与设备预付投入</td></tr><tr><td rowspan=1 colspan=1>合同负债</td><td rowspan=1 colspan=1>590</td><td rowspan=1 colspan=1>450</td><td rowspan=1 colspan=1>+31.1%</td><td rowspan=1 colspan=1>车规与工业长协订单预收增加</td></tr><tr><td rowspan=1 colspan=1>长期借款</td><td rowspan=1 colspan=1>5,520</td><td rowspan=1 colspan=1>4,860</td><td rowspan=1 colspan=1>+13.6%</td><td rowspan=1 colspan=1>武汉Fab3项目长期贷款提款</td></tr><tr><td rowspan=1 colspan=1>未分配利润</td><td rowspan=1 colspan=1>9,600</td><td rowspan=1 colspan=1>9,000</td><td rowspan=1 colspan=1>+6.7%</td><td rowspan=1 colspan=1>净利润积累扣除现金分红</td></tr></table>

资料来源：公司2024年年度报告(经审计)

简明分析：公司盈利质量与现金流状况良好，经营活动现金流对净利润覆盖倍数达4.8倍，主要受折旧摊销规模大及预收模式支撑。资产负债率37.7%，有息负债以长期借款为主，期限结构与资产回收周期匹配。经审阅，公司财务报表在所有重大方面公允反映了2024年12月31日的合并财务状况及2024年度合并经营成果和现金流量。

审计情况说明：中衡会计师事务所（特殊普通合伙）对公司2024年度财务报表实施了审计，并出具标准无保留意见的审计报告(中衡审字[2025]第0388号)，不涉及与持续经营相关的重大不确定性；该所同时对公司财务报告内部控制的有效性出具了标准无保留意见的内部控制审计报告。公司自2021年度起连续聘请该所提供审计服务，本节所列财务数据均取自经审计的合并财务报表，口径与审计报告一致。

附表1：非经常性损益明细（单位：万元）
<table><tr><td rowspan=1 colspan=1>项目</td><td rowspan=1 colspan=1>2024年</td><td rowspan=1 colspan=1>2023年</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>计入当期损益的政府补助</td><td rowspan=1 colspan=1>10,200</td><td rowspan=1 colspan=1>8,900</td><td rowspan=1 colspan=1>产业扶持与研发专项（税后归母口径）</td></tr><tr><td rowspan=1 colspan=1>理财产品及利息增值收益</td><td rowspan=1 colspan=1>2,900</td><td rowspan=1 colspan=1>1,800</td><td rowspan=1 colspan=1>闲置资金现金管理</td></tr><tr><td rowspan=1 colspan=1>股权处置及投资收益</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>500</td><td rowspan=1 colspan=1>参股公司股权处置</td></tr><tr><td rowspan=1 colspan=1>金融资产公允价值变动损益</td><td rowspan=1 colspan=1>700</td><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>结构性存款等金融资产</td></tr><tr><td rowspan=1 colspan=1>其他营业外收支净额</td><td rowspan=1 colspan=1>600</td><td rowspan=1 colspan=1>1,400</td><td rowspan=1 colspan=1>罚没支出、捐赠等</td></tr><tr><td rowspan=1 colspan=1>合计</td><td rowspan=1 colspan=1>14,800</td><td rowspan=1 colspan=1>13,000</td><td rowspan=1 colspan=1>占2024年归母净利润16.6%</td></tr></table>

资料来源：公司2024年年度报告(已列示为税后归母口径，合计与第二节非经常性损益1.48亿元一致)

附表2：前十大股东持股情况(截至2024年12月31日)
<table><tr><td colspan="1" rowspan="1">序号</td><td colspan="1" rowspan="1">股东名称</td><td colspan="1" rowspan="1">股东性质</td><td colspan="1" rowspan="1">持股数量（亿股）</td><td colspan="1" rowspan="1">持股比例</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">香港中央结算（代理人）有限公司</td><td colspan="1" rowspan="1">境外法人</td><td colspan="1" rowspan="1">4.80</td><td colspan="1" rowspan="1">28.6%</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">无锡澜创产业投资集团有限公司</td><td colspan="1" rowspan="1">国有法人</td><td colspan="1" rowspan="1">3.96</td><td colspan="1" rowspan="1">23.6%</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">无锡市产业发展投资基金（有限合伙）</td><td colspan="1" rowspan="1">国有法人</td><td colspan="1" rowspan="1">1.43</td><td colspan="1" rowspan="1">8.5%</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">国家集成电路产业投资基金二期股份有限公司</td><td colspan="1" rowspan="1">国有法人</td><td colspan="1" rowspan="1">0.84</td><td colspan="1" rowspan="1">5.0%</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">全国社保基金——四组合</td><td colspan="1" rowspan="1">其他</td><td colspan="1" rowspan="1">0.49</td><td colspan="1" rowspan="1">2.9%</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">中国人寿保险股份有限公司 - 传统 - 普通保险产品</td><td colspan="1" rowspan="1">其他</td><td colspan="1" rowspan="1">0.39</td><td colspan="1" rowspan="1">2.3%</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">无锡新尚产业投资有限公司</td><td colspan="1" rowspan="1">国有法人</td><td colspan="1" rowspan="1">0.32</td><td colspan="1" rowspan="1">1.9%</td></tr><tr><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1">基本养老保险基金八零二组合</td><td colspan="1" rowspan="1">其他</td><td colspan="1" rowspan="1">0.24</td><td colspan="1" rowspan="1">1.4%</td></tr><tr><td colspan="1" rowspan="1">9</td><td colspan="1" rowspan="1">华夏上证科创板50成份交易型开放式指数基金</td><td colspan="1" rowspan="1">其他</td><td colspan="1" rowspan="1">0.18</td><td colspan="1" rowspan="1">1.1%</td></tr><tr><td colspan="1" rowspan="1">10</td><td colspan="1" rowspan="1">广发制造业精选混合型证券投资基金</td><td colspan="1" rowspan="1">其他</td><td colspan="1" rowspan="1">0.15</td><td colspan="1" rowspan="1">0.9%</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">前十大股东合计</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">12.80</td><td colspan="1" rowspan="1">76.2%</td></tr></table>

资料来源：公司2024年年度报告（香港中央结算（代理人）有限公司所持股份为其名义持有的H股股份；控股股东所持股份不存在质押、冻结情形)

备查文件：(一）载有公司法定代表人、主管会计工作负责人及会计机构负责人签名并盖章的2024年度财务报表；（二）载有会计师事务所盖章、注册会计师签名并盖章的审计报告原件；（三）报告期内在中国证监会指定信息披露媒体公开披露过的所有文件的正本及公告原稿；(四）公司2024年度内部控制评价报告；(五）以中文及英文两种语言刊载的年度报告文本。以上备查文件存放于公司董事会办公室，投资者可登录上海证券交易所网站或公司网站查阅。

(本报告为虚构公司模拟数据，仅供知识库检索与研究测试使用)